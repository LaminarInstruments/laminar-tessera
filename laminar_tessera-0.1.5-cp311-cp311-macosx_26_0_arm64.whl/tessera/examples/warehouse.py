"""
Integrated example — an autonomous warehouse, six of Tessera's seven doors on ONE shared state.

This is the example that shows why one engine matters. The same state flows
through six of Tessera's seven capabilities without assembling an integration stack:

    signals  -> detect a shortage from the measurement stream
    graph    -> find which supplier serves the affected warehouse
    agents   -> explore two purchase options on a fork, pick one
    store    -> record the chosen purchase order durably
    workflow -> run the (resumable) approve -> send steps on that PO
    replay   -> keep an auditable event log, reconstruct the decision history

Then it forces a restart and shows the entire thing survives in one file.

Run:  python3 -m tessera.examples.warehouse
"""
import tempfile

from tessera.space import Space
from tessera.agents import Field, Program


def main():
    tmp = tempfile.mkdtemp()
    space = Space("warehouse-A", persistence=tmp)

    # 1) SIGNALS — a falling stock stream; is the latest reading a shortage?
    readings = [120, 118, 95, 60, 40]
    space.signals.measure("stock", readings)
    reorder_point = 100
    space.store.put("reorder_point", reorder_point)          # 2) STORE durable config
    level = readings[-1]
    shortage = level < reorder_point
    print(f"[signals] stock stream {readings} · latest={level} · shortage={shortage}")

    # 3) GRAPH — which suppliers serve this warehouse? rank them.
    (space.graph
        .connect("warehouse-A", "supplier-acme")
        .connect("warehouse-A", "supplier-globex")
        .connect("supplier-acme", "port-1"))          # acme is better-connected
    candidates = space.graph.neighbors("warehouse-A")
    preferred = space.graph.rank()[0] if space.graph.rank() else candidates[0]
    # choose the warehouse's supplier with the most connections (most capable)
    supplier = max(candidates, key=lambda s: space.graph.degree(s))
    print(f"[graph]   suppliers={candidates} · most-connected overall={preferred} · chosen={supplier}")

    # 4) AGENTS — record the situation, then fork two purchase options and pick one
    space.agents.observe({"stock": level, "reorder_point": reorder_point, "supplier": supplier})
    if shortage:
        # explore both options on isolated forks (no effect on live state)
        opt_small = space.agents.fork(); opt_small.run(Program("purchase"), qty=50,  supplier=supplier)
        opt_full  = space.agents.fork(); opt_full.run(Program("purchase"), qty=100, supplier=supplier)
        # decision rule: order back up to the reorder point
        chosen_qty = reorder_point - level                      # 60
        # record the chosen decision onto the SHARED state (in place, keeps sharing)
        space.agents.observe({"decision": "purchase", "qty": chosen_qty, "supplier": supplier})
        print(f"[agents]  explored qty=50 and qty=100 on forks; chose qty={chosen_qty}")

        # 5) STORE — the durable purchase order
        po = {"supplier": supplier, "qty": chosen_qty, "status": "open"}
        space.store.put("open_po", po)

        # 6) WORKFLOW — process that PO in resumable steps. If this crashes
        # after "approve" but before "send", a reload + re-run resumes AT
        # "send" instead of re-approving.
        def approve(ctx):
            space.store.put("open_po", {**space.store.get("open_po"), "status": "approved"})
            return {"approved_by": "auto-policy"}

        def send(ctx):
            assert ctx["approve"]["approved_by"]     # each step's result lands under its own name
            space.store.put("open_po", {**space.store.get("open_po"), "status": "sent"})
            return {"sent_to": supplier}

        space.workflow.add("approve", approve)
        space.workflow.add("send", send)
        space.workflow.run()

        # 7) REPLAY — append the decision trail
        space.replay.append({"event": "shortage_detected", "level": level})
        space.replay.append({"event": "po_created", **po})
        space.replay.append({"event": "po_processed", "status": space.store.get("open_po")["status"]})

    space.save()     # ONE file holds signals + graph + store + agent + log
    print(f"[save]    whole space persisted to one file")

    # ---- force a restart: reload EVERYTHING from the single file ----
    reloaded = Space.load("warehouse-A", persistence=tmp)
    print("\n[restart] reloaded one Space; every door's state is intact:")
    print("   store.open_po     =", reloaded.store.get("open_po"))
    print("   agents.state      =", reloaded.agents.state())
    print("   graph.degree(A)   =", reloaded.graph.degree("warehouse-A"))
    print("   signals.stats     =", {k: round(v, 1) for k, v in reloaded.signals.stats("stock").items()})
    print("   workflow.completed=", reloaded.workflow.completed())

    # reconstruct the decision history purely from the event log
    def summary(acc, e):
        acc = acc or []
        return acc + [e["event"]]
    print("   replay.history    =", reloaded.replay.reconstruct(summary, []))

    # six of Tessera's seven capabilities, one engine, one saved unit of state.
    assert reloaded.store.get("open_po")["qty"] == 60
    assert reloaded.store.get("open_po")["status"] == "sent"
    assert reloaded.agents.state()["decision"] == "purchase"
    assert reloaded.graph.degree("warehouse-A") == 2
    assert reloaded.workflow.completed() == ["approve", "send"]
    assert reloaded.replay.reconstruct(summary, []) == ["shortage_detected", "po_created", "po_processed"]
    print("\nOK — signals -> graph -> agents -> store -> workflow -> replay, composed on ONE shared state.")


if __name__ == "__main__":
    main()
