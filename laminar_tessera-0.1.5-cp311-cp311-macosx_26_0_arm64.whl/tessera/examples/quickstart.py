"""
Tessera quickstart — six of Tessera's seven doors, in plain usage.

Run it:   cd <repo root>  &&  python3 -m tessera.examples.quickstart

Every call here dispatches to the real engine (tessera._engine.spu121.SPU121).
This file doubles as the reference a coding assistant can read to learn the API.
"""
import tempfile
import tessera


def main():
    tmp = tempfile.mkdtemp()
    print("tessera", tessera.__version__, "·", tessera.engine_info()["opcodes"], "opcodes\n")

    # 1) agents — remember & decide ------------------------------------------
    from tessera.agents import Field, Program
    agent = Field("warehouse", persistence=tmp)
    agent.observe({"stock": 120, "demand": 145})
    branch = agent.fork()                      # explore a future in isolation
    branch.run(Program("restock"), quantity=100)
    agent.commit(branch)                       # keep that choice
    agent.save()                               # survives a crash
    print("agents   ->", agent.state())

    # 2) store — keep it safe (atomic transactions) --------------------------
    from tessera.store import Store
    s = Store(persistence=tmp, name="inv")
    s.put("widgets", 120)
    try:
        with s.transaction():                  # all-or-nothing
            s.put("widgets", 80)
            raise RuntimeError("abort")
    except RuntimeError:
        pass
    print("store    -> widgets =", s.get("widgets"), "(rollback undid the 80)")

    # 3) graph — track connections -------------------------------------------
    from tessera.graph import Graph
    g = Graph()
    g.connect("order", "payment").connect("payment", "ledger")
    print("graph    -> path =", g.path("order", "ledger"), "| rank =", g.rank())

    # 4) signals — watch the numbers -----------------------------------------
    from tessera.signals import Signals
    sig = Signals()
    sig.measure("hr", [72, 75, 71, 80, 69, 77])
    print("signals  -> stats =", {k: round(v, 1) for k, v in sig.stats("hr").items()},
          "| entropy(spread) =", round(sig.entropy([10, 90, 20, 80, 5, 95]), 2))

    # 5) workflow — finish the job (resumable) -------------------------------
    from tessera.workflow import Workflow
    wf = Workflow("checkout", persistence=tmp)

    @wf.step
    def reserve(ctx): return {"held": ctx["qty"]}

    @wf.step
    def charge(ctx): return {"paid": True}

    wf.run({"qty": 3})
    print("workflow -> completed =", wf.completed())

    # 6) replay — prove what happened ----------------------------------------
    from tessera.replay import EventLog
    log = EventLog(persistence=tmp, name="acct")
    log.append({"type": "deposit", "amount": 100})
    log.append({"type": "withdraw", "amount": 30})

    def balance(acc, e):
        acc = acc or 0
        return acc + e["amount"] if e["type"] == "deposit" else acc - e["amount"]

    print("replay   -> balance from events =", log.reconstruct(balance, 0))


if __name__ == "__main__":
    main()
