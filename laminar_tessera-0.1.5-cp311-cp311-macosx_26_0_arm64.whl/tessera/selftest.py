"""Prove the tessera front door is REAL: run the website's hero code verbatim,
exercise all seven doors, and confirm every call hit the real SPU121 engine."""
import tempfile, os, sys

print("=" * 70)
import tessera
print("tessera", tessera.__version__, "·", tessera.engine_info())
assert tessera.engine_info()["opcodes"] == 121

# ---- 1. the EXACT hero code from the website -------------------------------
print("\n[1] website hero code (agents)")
from tessera.agents import Field, Program
tmp = tempfile.mkdtemp()
agent = Field("warehouse", persistence=tmp)
agent.observe({"stock": 120, "demand": 145})
branch = agent.fork()
branch.run(Program("restock"), quantity=100)
agent.commit(branch)
path = agent.save()
print("   state:", agent.state(), "| events:", len(agent.history()), "| saved:", os.path.basename(path))
assert agent.state()["quantity"] == 100          # the committed decision stuck
assert os.path.exists(path)
reloaded = Field.load("warehouse", persistence=tmp)
assert reloaded.state()["quantity"] == 100        # survived save -> load
print("   reloaded after crash:", reloaded.state(), "OK")

# fork isolation: a branch must NOT leak into live state until commit
fresh = Field("iso", persistence=None)
fresh.observe({"x": 1})
b = fresh.fork(); b.run(Program("mut"), x=999)
assert fresh.state()["x"] == 1, "fork leaked!"
print("   fork isolation: live x still 1 while branch x=999  OK")

# ---- 2. store: transactions + rollback -------------------------------------
print("\n[2] store (keep it safe)")
from tessera.store import Store
s = Store(persistence=tmp, name="inv")
s.put("widgets", 120)
try:
    with s.transaction():
        s.put("widgets", 80)
        raise RuntimeError("boom")
except RuntimeError:
    pass
assert s.get("widgets") == 120, "rollback failed!"
print("   widgets after rolled-back txn:", s.get("widgets"), "(still 120) OK")
with s.transaction():
    s.put("widgets", 200)
assert s.get("widgets") == 200
print("   widgets after committed txn:", s.get("widgets"), "OK")

# ---- 3. graph ---------------------------------------------------------------
print("\n[3] graph (track connections)")
from tessera.graph import Graph
g = Graph()
g.connect("order", "payment").connect("payment", "ledger").connect("order", "email")
print("   degree(payment)=", g.degree("payment"),
      "| path(order->ledger)=", g.path("order", "ledger"),
      "| rank=", g.rank()[:2])
assert g.degree("payment") == 2
assert g.path("order", "ledger") == ["order", "payment", "ledger"]
assert g.rank()[0] in ("order", "payment")   # the two most-connected

# ---- 4. signals -------------------------------------------------------------
print("\n[4] signals (watch the numbers)")
from tessera.signals import Signals
sig = Signals()
sig.measure("hr", [72, 75, 71, 80, 69, 77, 73, 74])
flat_e = sig.entropy([70, 70, 70, 70])
wild_e = sig.entropy([10, 90, 20, 80, 30, 70, 5, 95])
print("   stats(hr)=", {k: round(v, 2) for k, v in sig.stats("hr").items()})
print("   entropy flat=", round(flat_e, 3), " wild=", round(wild_e, 3))
assert flat_e < wild_e, "entropy direction wrong!"
esc, e = sig.gate([70, 250, 71, 69], threshold=1.0)
print("   gate(spiky, thr=1.0) -> escalate=", esc, "entropy=", round(e, 3))

# ---- 5. workflow: crash + resume -------------------------------------------
print("\n[5] workflow (finish the job, resume after crash)")
from tessera.workflow import Workflow
wf = Workflow("checkout", persistence=tmp)
log = []
@wf.step
def reserve(ctx): log.append("reserve"); return {"held": ctx["qty"]}
@wf.step
def charge(ctx):  log.append("charge");  return {"paid": True}
wf.run({"qty": 3})
assert log == ["reserve", "charge"]
# simulate a crash+restart: reload and add a 3rd step; done ones must NOT rerun
wf2 = Workflow.load("checkout", persistence=tmp)
ran2 = []
@wf2.step
def reserve(ctx): ran2.append("reserve"); return {"held": 0}
@wf2.step
def charge(ctx):  ran2.append("charge");  return {}
@wf2.step
def ship(ctx):    ran2.append("ship");    return {"tracking": "XZ-1"}
ctx = wf2.run({"qty": 3})
print("   completed before restart:", ["reserve", "charge"])
print("   ran on restart:", ran2, "(only the new step)")
assert ran2 == ["ship"], f"resume reran completed steps: {ran2}"
assert ctx["reserve"]["held"] == 3   # prior result restored from disk
print("   resumed context carries prior results:", ctx.get("ship"), "OK")

# ---- 6. replay: event sourcing ---------------------------------------------
print("\n[6] replay (prove what happened)")
from tessera.replay import EventLog
el = EventLog(persistence=tmp, name="acct")
el.append({"type": "deposit", "amount": 100})
el.append({"type": "withdraw", "amount": 30})
el.append({"type": "deposit", "amount": 10})
def balance(acc, ev):
    acc = acc or 0
    return acc + ev["amount"] if ev["type"] == "deposit" else acc - ev["amount"]
bal = el.reconstruct(balance, initial=0)
print("   3 events ->", el.events()[-1], "| reconstructed balance=", bal)
assert bal == 80
el2 = EventLog.load("acct", persistence=tmp)
assert el2.reconstruct(balance, 0) == 80   # replay survives reload
print("   replay after reload = 80  OK")

# ---- 7. baseline: adaptive EMA + entropy drift (first public door onto it) -
print("\n[7] baseline (learn what normal looks like, and let it move)")
from tessera.baseline import AdaptiveBaseline
b = AdaptiveBaseline("latency", persistence=tmp)
b.set_rate(alpha=0.5, beta=0.5)
steady_vals, drift_vals = [10, 11, 9, 10, 11, 9, 10, 11], [10, 9, 50, 9, 50, 9, 50, 9]
v1 = b.learn_many(steady_vals)
osc1 = b.oscillating(threshold=0.5)
b2 = AdaptiveBaseline("latency-osc", persistence=tmp)
b2.set_rate(alpha=0.5, beta=0.5)
v2 = b2.learn_many(drift_vals)
osc2 = b2.oscillating(threshold=0.5)
print("   steady series -> baseline=", round(v1, 2), "oscillating=", osc1,
      "| flapping series -> baseline=", round(v2, 2), "oscillating=", osc2)
assert osc1 is False and osc2 is True, "oscillation detector didn't tell steady from flapping"
b.save()
reloaded_b = AdaptiveBaseline.load("latency", persistence=tmp)
assert abs(reloaded_b.value() - v1) < 1e-9, "baseline didn't survive save/load"
print("   baseline survived save -> load:", round(reloaded_b.value(), 2), "OK")

flat_hist, spread_hist = [10, 10, 10, 11], [5, 20, 40, 60, 80, 100, 120, 140]
assert b.track_entropy(flat_hist) is True            # first call always "drops" (no prior baseline)
drifted = b.entropy_drift(spread_hist)
print("   entropy_drift(evenly-spread vs flat baseline) =", round(drifted, 3))
assert drifted > 0, "a series spread evenly across its own range should read higher than a flat baseline"

# ---- 8. space: a branch committed through Space.agents must survive save/
# reload exactly like every other door. Regression guard for a real bug: an
# earlier Field.commit() rebound self._spu to a new object instead of
# mutating it in place, which silently detached the agent from a Space's
# shared engine — Space.save() kept serializing the stale pre-commit state
# while agents.state() (reading the Field's own, now-detached _spu) looked
# correct right up until the next reload. Standalone Field.commit() never
# exposed this (nothing else held a reference to the old object), and
# neither did this file's own section [1] above, which only exercises a
# standalone Field — this check is the one that would have caught it.
print("\n[8] space (branch-commit survives save -> reload, not just observe())")
from tessera.space import Space
sp_tmp = tempfile.mkdtemp()
sp = Space("routing", persistence=sp_tmp)
sp_branch = sp.agents.fork()
sp_branch.run(Program("candidate"), choice="reroute")
sp.agents.commit(sp_branch)
sp.store.put("decision", "reroute")
sp.replay.append({"event": "reroute"})
sp.save()
sp_reloaded = Space.load("routing", persistence=sp_tmp)
print("   store.decision     =", sp_reloaded.store.get("decision"))
print("   agents.state()     =", sp_reloaded.agents.state())
print("   agents.history len =", len(sp_reloaded.agents.history()))
assert sp_reloaded.agents.state().get("choice") == "reroute", \
    "agent branch-commit did not survive Space save/reload!"
assert len(sp_reloaded.agents.history()) > 0, \
    "agent branch run history lost across Space save/reload!"
print("   branch-commit survived Space save -> load  OK")

print("\n" + "=" * 70)
print("ALL SEVEN DOORS REAL · every call dispatched to tessera._engine.spu121.SPU121")
print("=" * 70)
