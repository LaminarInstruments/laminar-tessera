"""
tessera.core — the shared foundation every door opens onto.

Tessera is NOT a reimplementation. It is the clean front door over the real
engine: `tessera._engine.spu121.SPU121`, the full 121-opcode software SPU.
Every method in every tessera door dispatches to a real SPU opcode — no stubs,
no parallel logic. If you want the raw engine, it is one import away:

    from tessera.core import engine, SPU121

Determinism, crash-safe dispatch, atomic save()/load(), and transactional
rollback are all properties of that engine, inherited here unchanged.
"""
from pathlib import Path

# The engine, shipped compiled (tessera._engine). histogram8 is the SDK's
# binning helper (keeps entropy honest:
# a flat series -> one bin -> low entropy; a spread series -> all bins -> high).
from tessera._engine.spu121 import SPU121, ALL_121 as _ALL_121
# histogram8 is inlined below

def histogram8(samples):
    """Bin a numeric series into 8 equal-width bins -> 8 counts.
    Standard binning (not IP); keeps the compiled-engine dependency minimal."""
    import math as _m
    xs = []
    for v in (samples or []):
        try:
            f = float(v)
            if _m.isfinite(f):
                xs.append(f)
        except (TypeError, ValueError):
            continue
    if not xs:
        return [0] * 8
    lo, hi = min(xs), max(xs)
    if hi == lo:
        return [len(xs)] + [0] * 7
    span = hi - lo
    width = span / 8.0 if _m.isfinite(span) else 0.0
    if not _m.isfinite(span) or span == 0 or width == 0:
        # Extreme-magnitude values (e.g. ~1e308) can make hi - lo itself
        # overflow to inf, then (x - lo) / width become inf / inf = nan, and
        # int(nan) raise ValueError. A DIFFERENT failure mode: span can stay
        # finite but still be so small (e.g. 5e-324, the smallest denormal)
        # that span / 8.0 underflows to exactly 0.0, causing a
        # ZeroDivisionError at bin-index time even though span itself was
        # never zero. Both are caught by checking width itself, not just span.
        #
        # Fall back to binning by UNIQUE VALUE RANK, not by raw sorted
        # INDEX — an index-based rank previously put several EQUAL huge
        # values in different bins purely because of where they landed in
        # the sort, which is wrong: equal readings must always land in the
        # same bin. Ranking the distinct values and assigning every
        # occurrence of a value to its unique value's bin fixes that, and
        # never needs the overflowing/underflowing span at all.
        uniq = sorted(set(xs))
        m = len(uniq)
        bin_of = {v: min(7, (i * 8) // m) for i, v in enumerate(uniq)}
        bins = [0] * 8
        for x in xs:
            bins[bin_of[x]] += 1
        return bins
    bins = [0] * 8
    for x in xs:
        idx = int((x - lo) / width)
        if idx > 7:
            idx = 7
        elif idx < 0:
            idx = 0
        bins[idx] += 1
    return bins


__all__ = ["SPU121", "histogram8",
           "engine", "persist_dir", "save_path", "engine_info",
           "ConcurrentWriteError", "InvalidSaveFileError", "safe_load"]


def engine():
    """A fresh engine instance. Every tessera door wraps one of these."""
    return SPU121()


def persist_dir(persistence):
    """Resolve a persistence target into a directory (or None for in-memory).

    persistence=None / "memory" / False  -> in-memory only (no file)
    persistence="local" / True           -> ~/.tessera
    persistence=<any other non-empty string/Path>  -> that directory

    Raises ValueError for an empty string — without this check it silently
    resolved to the current working directory, which is almost never what a
    caller meant by "" and was found during adversarial testing to produce a
    save file in whatever directory the process happened to be run from.
    """
    if persistence in (None, False, "memory"):
        return None
    if persistence in (True, "local"):
        base = Path.home() / ".tessera"
    elif persistence == "":
        raise ValueError(
            "persistence='' is not a valid target (it would silently resolve to the "
            "current working directory). Use None for in-memory, 'local' for ~/.tessera, "
            "or a real directory path."
        )
    else:
        base = Path(persistence)
    base.mkdir(parents=True, exist_ok=True)
    return base


def save_path(name, persistence, suffix):
    """Where a door's save file would live for (name, persistence), or None
    for in-memory persistence. Shared by every door's open()/create()."""
    d = persist_dir(persistence)
    return (d / f"{name}.{suffix}") if d is not None else None


class ConcurrentWriteError(RuntimeError):
    """Raised when two writers race the same persisted (name, persistence)
    and the underlying atomic rename collides. This does NOT mean your data
    is safe — the other writer's save may still have partially lost updates
    (see COOKBOOK.md: no multi-writer coordination is provided). It means
    this call, specifically, could not complete, and you get a clear error
    instead of an internals-leaking FileNotFoundError from the compiled
    engine's rename step."""
    pass


class InvalidSaveFileError(ValueError):
    """Raised when a file passed to .load() exists but isn't a valid Tessera
    save (corrupted JSON, or valid JSON in the wrong shape — e.g. a bare
    list instead of the expected object). Previously these failed with a
    raw JSONDecodeError or an internals-leaking AttributeError
    ('list' object has no attribute 'get')."""
    pass


_REQUIRED_SAVE_KEYS = ("_t", "lfsr", "desc", "cache")   # always present in a
                                                          # real save, verified
                                                          # identical across
                                                          # every door's file


def safe_load(path):
    """load() wrapper every door's load() should call instead of
    SPU121.load(path) directly — turns a corrupted or wrong-shape save file
    into a clear, catchable InvalidSaveFileError instead of a raw
    JSONDecodeError/AttributeError leaking the engine's internal shape.

    Also rejects syntactically-valid-but-schema-empty JSON (e.g. "{}") —
    found during adversarial testing: the engine's loader fills in missing
    keys with defaults rather than failing, so a truncated or corrupted file
    that happens to still parse as valid JSON (a bug elsewhere overwriting
    it with "{}", a half-written file, disk corruption that zeroes content)
    silently loaded as "a legitimate empty save," indistinguishable from the
    real thing. A real save always contains the full engine schema; this
    checks for that schema's required keys before trusting the result."""
    import json
    try:
        with open(path) as f:
            raw = json.load(f)
    except FileNotFoundError:
        raise
    except (ValueError, UnicodeDecodeError) as e:
        raise InvalidSaveFileError(
            f"{path} exists but is not valid JSON ({type(e).__name__}: {e})."
        ) from e

    if not isinstance(raw, dict) or not all(k in raw for k in _REQUIRED_SAVE_KEYS):
        raise InvalidSaveFileError(
            f"{path} is valid JSON but missing the expected Tessera save schema "
            f"(required keys: {_REQUIRED_SAVE_KEYS}) — likely corrupted, "
            f"truncated, or not a Tessera save file at all."
        )

    try:
        return SPU121.load(str(path))
    except FileNotFoundError:
        raise
    except (ValueError, AttributeError, TypeError, KeyError) as e:
        raise InvalidSaveFileError(
            f"{path} exists but is not a valid Tessera save file "
            f"({type(e).__name__}: {e})."
        ) from e


def safe_save(spu, path):
    """save() wrapper every door's save() should call instead of
    spu.save(path) directly — turns the concurrent-writer race (two
    processes save()ing the same name at once) from an uncaught,
    internals-leaking FileNotFoundError into a clear, catchable
    ConcurrentWriteError.

    A missing PARENT DIRECTORY raises the same underlying FileNotFoundError
    from the same rename step, but is a completely different situation (no
    other writer involved) — checked for explicitly first and re-raised as
    plain FileNotFoundError, so the two causes are no longer indistinguishable."""
    parent = Path(path).parent
    if not parent.is_dir():
        raise FileNotFoundError(f"{parent} does not exist — create it before calling save().")
    try:
        return spu.save(str(path))
    except FileNotFoundError as e:
        raise ConcurrentWriteError(
            f"Concurrent write collision while saving {path} — another process "
            f"saved to the same persisted name at the same time. Tessera has no "
            f"multi-writer coordination (see COOKBOOK.md); treat this name as "
            f"single-writer, or add your own locking."
        ) from e


def engine_info():
    """What's actually running underneath — proof the front door is real."""
    return {
        "engine": "tessera._engine.spu121.SPU121 (compiled)",
        "opcodes": len(_ALL_121),
        "deterministic": True,
        "dependencies": 0,
        "patent": "pending",
        "author": "Darreck L. Bender II, Founder, Laminar Instruments",
        "contact": "darreck@laminarinstruments.com",
        "url": "https://laminarinstruments.com",
    }
