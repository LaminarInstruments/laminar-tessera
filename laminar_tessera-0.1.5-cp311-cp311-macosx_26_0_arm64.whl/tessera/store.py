"""
tessera.store — keep it safe.

Durable, embedded key/value state with all-or-nothing transactions and exact
rollback. No server.

    from tessera.store import Store

    s = Store.open(persistence="local", name="inventory")   # load-or-create
    s.put("widgets", 120)
    with s.transaction():          # all-or-nothing
        s.put("widgets", 80)
        raise RuntimeError("oops") # -> rolled back; widgets is still 120
    s.save()

Backed by SPU121 descriptors (the KV) and BEGIN/COMMIT/ROLLBACK_TRANSACTION
(the atomicity). save()/load() are the engine's atomic durable persistence.
"""
import copy

from .core import SPU121, persist_dir, save_path, safe_save, safe_load

__all__ = ["Store"]

_UNIT = "__store__"
_KEY_TYPES = "__store_key_types__"


def _detach(value):
    """Deep-copy on the way in/out of the Store so neither a caller's
    held reference nor a reload can mutate the other's view of the same
    nested object (dicts/lists are stored and returned BY VALUE, not by
    reference — previously put(k, v) then mutating the caller's v, or
    mutating a returned get(k), silently corrupted the stored value)."""
    return copy.deepcopy(value)


def _validate_json_keys(value, path="value"):
    """Reject a dict with two keys that stringify to the same JSON key
    (e.g. {1: 'a', '1': 'b'}) — the engine's save() goes through
    json.dump, which silently collapses such a dict to one entry at
    whichever key python's json encoder visits last. Recurses into
    nested dicts/lists so this is caught anywhere in the value, not just
    at the top level."""
    if isinstance(value, dict):
        seen = {}
        for k, v in value.items():
            sk = str(k)
            if sk in seen and seen[sk] != k:
                raise ValueError(
                    f"Store.put: {path} contains keys {seen[sk]!r} and {k!r} that "
                    f"both stringify to {sk!r} — persistence (JSON) can only keep "
                    f"one of them. Use one consistent key type."
                )
            seen[sk] = k
            _validate_json_keys(v, path=f"{path}[{k!r}]")
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            _validate_json_keys(v, path=f"{path}[{i}]")


def _normalize_tuples(value):
    """Tuples have no JSON representation and silently became lists the
    first time a Store round-tripped through save()/load() — normalize
    them to lists immediately at put() time instead, so the type is
    consistent from the very first call, not just after a restart."""
    if isinstance(value, tuple):
        return [_normalize_tuples(x) for x in value]
    if isinstance(value, list):
        return [_normalize_tuples(x) for x in value]
    if isinstance(value, dict):
        return {k: _normalize_tuples(v) for k, v in value.items()}
    return value


class _Txn:
    """Context manager: commit on clean exit, roll back on any exception.

    Also usable as an ASYNC context manager (`async with store.transaction():`)
    for code spanning await points inside the block. The sync path is
    unchanged; the async path additionally acquires a lock shared by this
    Store instance, so two tasks can no longer have a transaction open on
    the same Store's engine at once — found via adversarial testing that
    two overlapping async transactions on one shared Store interleaved on
    the engine's single txn_stack, so cancelling one task's transaction
    could silently undo part of another, unrelated task's writes."""
    def __init__(self, spu, owner):
        self._spu = spu
        self._owner = owner
        self._locked = False

    def __enter__(self):
        self._owner._txn_depth += 1
        self._spu.execute("BEGIN_TRANSACTION")
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self._spu.execute("COMMIT_TRANSACTION")
            else:
                self._spu.execute("ROLLBACK_TRANSACTION")
        finally:
            self._owner._txn_depth -= 1
        return False   # never swallow the exception — rollback then re-raise

    async def __aenter__(self):
        import asyncio
        if self._owner._txn_lock is None:
            self._owner._txn_lock = asyncio.Lock()
        await self._owner._txn_lock.acquire()
        self._locked = True
        return self.__enter__()

    async def __aexit__(self, exc_type, exc, tb):
        try:
            return self.__exit__(exc_type, exc, tb)
        finally:
            if self._locked:
                self._owner._txn_lock.release()
                self._locked = False


class Store:
    def __init__(self, persistence=None, name="store", _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.store.json") if self._dir else None
        self._txn_depth = 0
        self._txn_lock = None  # lazily-created asyncio.Lock; see _Txn.__aenter__

    def put(self, key, value):
        """Set key -> value.

        Raises ValueError if `key` stringifies to the same thing as a
        DIFFERENTLY-TYPED key already stored (e.g. put(1, ...) after
        put("1", ...)) — the engine's descriptor storage is string-keyed, so
        without this check the second put() silently overwrote the first
        with no error at all. Also raises if `value` contains two dict keys
        that would collide after the same JSON stringification on save().

        `value` is deep-copied on the way in, and tuples anywhere inside it
        are normalized to lists immediately (not only after a save/reload —
        JSON has no tuple type, so this makes the type consistent from the
        very first call instead of changing out from under you on restart).
        """
        skey = str(key)
        this_repr = f"{type(key).__name__}:{key!r}"
        existing = self._spu.desc.get(_KEY_TYPES, {}).get(skey)
        if existing is not None and existing != this_repr:
            raise ValueError(
                f"Store.put: key {key!r} ({type(key).__name__}) collides with an "
                f"already-stored, differently-typed key that also stringifies to "
                f"{skey!r} ({existing}). Store keys are stringified internally — "
                f"use consistent key types, or call store.delete() first if you "
                f"intend to replace it."
            )
        _validate_json_keys(value)
        value = _normalize_tuples(_detach(value))
        self._spu.execute("ADD_DESCRIPTOR", unit=_KEY_TYPES, key=skey, value=this_repr)
        self._spu.execute("ADD_DESCRIPTOR", unit=_UNIT, key=skey, value=value)
        return self

    def get(self, key, default=None):
        if str(key) not in self._spu.desc.get(_UNIT, {}):
            return default
        return _detach(self._spu.desc[_UNIT][str(key)])

    def delete(self, key):
        """Remove key. Raises ValueError for the same cross-type collision
        put() rejects (e.g. delete(1) after put('1', ...)) — previously
        delete() used only str(key), so it could silently remove an entry
        that was put() under a different, non-colliding key type."""
        skey = str(key)
        this_repr = f"{type(key).__name__}:{key!r}"
        existing = self._spu.desc.get(_KEY_TYPES, {}).get(skey)
        if existing is not None and existing != this_repr:
            raise ValueError(
                f"Store.delete: key {key!r} ({type(key).__name__}) does not match "
                f"the type of the key actually stored at {skey!r} ({existing}). "
                f"Use the same key type you put() it with."
            )
        self._spu.execute("REMOVE_DESCRIPTOR", unit=_UNIT, key=skey)
        self._spu.execute("REMOVE_DESCRIPTOR", unit=_KEY_TYPES, key=skey)
        return self

    def keys(self):
        return list(self._spu.desc.get(_UNIT, {}).keys())

    def items(self):
        return _detach(dict(self._spu.desc.get(_UNIT, {})))

    def __contains__(self, key):
        return str(key) in self._spu.desc.get(_UNIT, {})

    def __len__(self):
        return len(self._spu.desc.get(_UNIT, {}))

    def transaction(self):
        """All-or-nothing block. On any exception, every write inside is undone.

        Use `async with store.transaction():` instead of `with` for a block
        that spans await points in async code — it serializes concurrent
        transactions on this same Store instance via a shared asyncio.Lock,
        so two tasks' transactions can no longer interleave on the shared
        engine state."""
        return _Txn(self._spu, self)

    def save(self, path=None):
        """Raises RuntimeError if called while a transaction() is still open
        on this Store — previously save() inside an open transaction wrote
        the UNCOMMITTED in-progress values straight to disk, so a save()
        followed by a rollback left the durable file permanently out of
        sync with the in-memory (correctly rolled-back) state. Save after
        the transaction exits (commits or rolls back) instead."""
        if self._txn_depth > 0:
            raise RuntimeError(
                "Store.save: a transaction() is still open on this Store — save() "
                "would persist uncommitted writes that a rollback could later undo "
                "only in memory, leaving disk permanently out of sync. Call save() "
                "after the transaction block exits."
            )
        p = path or self._path
        if p is None:
            raise ValueError("In-memory Store: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    @classmethod
    def load(cls, name="store", persistence="local", path=None):
        d = persist_dir(persistence)
        p = path or (d / f"{name}.store.json")
        return cls(persistence=persistence, name=name, _spu=safe_load(p))

    @classmethod
    def open(cls, name="store", persistence=None):
        """Load existing state if a save already exists for (name,
        persistence); otherwise create fresh. THE safe entry point for any
        restart path — see COOKBOOK.md Part 2.0. The plain constructor does
        NOT check for an existing save and will silently destroy it on the
        next save() if you construct fresh instead of loading."""
        p = save_path(name, persistence, "store.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(persistence=persistence, name=name)

    @classmethod
    def create(cls, name="store", persistence=None):
        """Create new state; raise FileExistsError if a save already exists
        for (name, persistence). Use this when resuming old state would
        itself be a bug — e.g. provisioning a brand-new entity that must not
        collide with a prior one of the same name."""
        p = save_path(name, persistence, "store.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Store.create: a save already exists for {name!r} at {p} — "
                f"use Store.open() to resume it, or Store.load() if you expect it to exist."
            )
        return cls(persistence=persistence, name=name)

    def __repr__(self):
        return f"Store({self.name!r}, keys={len(self)})"
