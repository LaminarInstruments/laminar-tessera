"""
tessera.space — one engine, all seven doors, ONE shared state.

This is Tessera's core proposition made literal: instead of wiring a database to
a cache to a graph store to a workflow engine to an event log to an adaptive
threshold tracker, you open one Space and every door operates on the *same*
state. One save() persists all of it; one load() brings all of it back.

    from tessera.space import Space

    space = Space("warehouse", persistence="local")
    space.signals.measure("stock", [120, 95, 60])     # measurement state
    space.graph.connect("warehouse", "supplier")      # relationship state
    space.store.put("reorder_point", 100)             # durable key/value
    space.agents.observe({"stock": 60})               # agent observation
    space.replay.append({"event": "shortage"})        # audit event
    space.baseline.learn(60)                           # adaptive baseline state
    space.save()                                       # ALL of it, one file

    # after a restart:
    space = Space.load("warehouse", persistence="local")
    space.store.get("reorder_point")                   # 100 — everything restored

Each door is bound to the same engine instance, so their slices of state
(measurements, graph, descriptors, events, feedback) live together and compose
without any integration glue. The individual doors (tessera.agents,
tessera.store, ...) still work standalone when you only need one.
"""
from typing import Optional, Union
from pathlib import Path

from .core import engine, persist_dir, save_path, safe_save, safe_load, SPU121
from .agents import Field
from .store import Store
from .graph import Graph
from .signals import Signals
from .workflow import Workflow
from .replay import EventLog
from .baseline import AdaptiveBaseline

__all__ = ["Space"]


class Space:
    """Seven doors sharing one engine and one unit of state."""

    def __init__(self, name: str = "space",
                 persistence: Optional[Union[str, bool]] = None,
                 _spu: Optional[SPU121] = None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else engine()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.space.json") if self._dir else None
        self._bind()

    def _bind(self) -> None:
        """Point every door at the shared engine."""
        self.agents = Field(self.name, _spu=self._spu)
        self.store = Store(name=self.name, _spu=self._spu)
        self.graph = Graph(name=self.name, _spu=self._spu)
        self.signals = Signals(name=self.name, _spu=self._spu)
        self.workflow = Workflow(self.name, _spu=self._spu)
        self.replay = EventLog(name=self.name, _spu=self._spu)
        self.baseline = AdaptiveBaseline(self.name, _spu=self._spu)

    def save(self, path: Optional[str] = None) -> str:
        """Persist the WHOLE shared state (every door) atomically to one file."""
        p = path or self._path
        if p is None:
            raise ValueError("In-memory Space: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    @classmethod
    def load(cls, name: str = "space",
             persistence: Union[str, bool] = "local",
             path: Optional[str] = None) -> "Space":
        """Reload a whole Space — all doors, one state — from disk."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.space.json")
        return cls(name=name, persistence=persistence, _spu=safe_load(p))

    @classmethod
    def open(cls, name: str = "space", persistence: Union[str, bool] = None) -> "Space":
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0. Space is especially exposed to the
        load-vs-construct trap: a fresh Space() on a restart silently
        discards EVERY door's state, not just one."""
        p = save_path(name, persistence, "space.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(name=name, persistence=persistence)

    @classmethod
    def create(cls, name: str = "space", persistence: Union[str, bool] = None) -> "Space":
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "space.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Space.create: a save already exists for {name!r} at {p} — "
                f"use Space.open() to resume it, or Space.load() if you expect it to exist."
            )
        return cls(name=name, persistence=persistence)

    def __repr__(self) -> str:
        where = "memory" if self._path is None else str(self._path)
        return f"Space({self.name!r}, {where})"
