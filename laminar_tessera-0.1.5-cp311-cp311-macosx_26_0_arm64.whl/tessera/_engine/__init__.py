"""Compiled engine (binary). Source is not distributed."""
