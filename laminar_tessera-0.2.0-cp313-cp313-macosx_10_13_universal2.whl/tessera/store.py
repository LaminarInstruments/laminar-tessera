"""
tessera.store — keep it safe.

Durable, embedded key/value state with all-or-nothing transactions and exact
rollback. No server.

    from tessera.store import Store

    s = Store.open(persistence="local", name="inventory")   # load-or-create
    s.put("widgets", 120)
    with s.transaction():          # all-or-nothing
        s.put("widgets", 80)
        raise RuntimeError("oops") # -> rolled back; widgets is still 120
    s.save()

Backed by SPU121 descriptors (the KV) and BEGIN/COMMIT/ROLLBACK_TRANSACTION
(the atomicity). save()/load() are the engine's atomic durable persistence.
"""
import copy

from .core import (SPU121, persist_dir, save_path, safe_save, safe_load,
                    prepare_for_persistence, to_thread)

__all__ = ["Store"]

_UNIT = "__store__"
_KEY_TYPES = "__store_key_types__"


def _detach(value):
    """Deep-copy on the way in/out of the Store so neither a caller's
    held reference nor a reload can mutate the other's view of the same
    nested object (dicts/lists are stored and returned BY VALUE, not by
    reference — previously put(k, v) then mutating the caller's v, or
    mutating a returned get(k), silently corrupted the stored value)."""
    return copy.deepcopy(value)


class _Txn:
    """Context manager: commit on clean exit, roll back on any exception.

    Also usable as an ASYNC context manager (`async with store.transaction():`)
    for code spanning await points inside the block — it acquires a lock
    shared by this Store instance, so two TASKS can no longer have a
    transaction open on the same Store's engine at once (found via
    adversarial testing: two overlapping async transactions on one shared
    Store interleaved on the engine's single txn_stack, so cancelling one
    task's transaction could silently undo part of another, unrelated
    task's writes). The lock is reentrant for the SAME task (a nested
    `async with store.transaction():` from within another on the same task
    does not re-acquire, which would otherwise deadlock — `asyncio.Lock` is
    not reentrant on its own).

    A plain sync `with` entered while an async transaction is currently
    held by a DIFFERENT task now raises RuntimeError instead of silently
    proceeding unguarded — found via adversarial testing that the sync path
    never touched the lock at all, so mixing `with` and `async with` on one
    Store reopened the exact interleaving bug the lock exists to prevent.
    Use `async with` consistently on a Store you also access from async
    code."""
    def __init__(self, spu, owner):
        self._spu = spu
        self._owner = owner
        self._locked = False
        self._sync_entered = False

    def __enter__(self):
        # A TRUE sync entry checks for conflict with an open ASYNC
        # transaction (the lock) — __aenter__ bypasses this (via _begin()
        # directly) since it has already correctly handled the lock itself,
        # including the reentrant same-task case.
        lock = self._owner._txn_lock
        if lock is not None and lock.locked():
            raise RuntimeError(
                "Store.transaction(): an async transaction (`async with`) is "
                "currently open on this Store from another task — a plain `with` "
                "cannot safely interleave with it. Use `async with "
                "store.transaction():` consistently for a Store also accessed "
                "from async code."
            )
        self._owner._sync_depth += 1
        self._sync_entered = True
        return self._begin()

    def _begin(self):
        self._owner._txn_depth += 1
        self._spu.execute("BEGIN_TRANSACTION")
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self._spu.execute("COMMIT_TRANSACTION")
            else:
                self._spu.execute("ROLLBACK_TRANSACTION")
        finally:
            self._owner._txn_depth -= 1
            if self._sync_entered:
                self._owner._sync_depth -= 1
        return False   # never swallow the exception — rollback then re-raise

    async def __aenter__(self):
        import asyncio
        if self._owner._sync_depth > 0:
            raise RuntimeError(
                "Store.transaction(): a sync transaction (`with`) is currently "
                "open on this Store — `async with` cannot safely interleave with "
                "it. Use `async with store.transaction():` consistently for a "
                "Store also accessed from async code."
            )
        if self._owner._txn_lock is None:
            self._owner._txn_lock = asyncio.Lock()
        lock = self._owner._txn_lock
        task = asyncio.current_task()
        if lock.locked() and self._owner._txn_lock_task is task:
            # Reentrant: this SAME task already holds the lock (a nested
            # `async with store.transaction():`) — re-acquiring would
            # deadlock (asyncio.Lock is not reentrant), so just nest.
            self._locked = False
        else:
            await lock.acquire()
            self._owner._txn_lock_task = task
            self._locked = True
        return self._begin()

    async def __aexit__(self, exc_type, exc, tb):
        try:
            return self.__exit__(exc_type, exc, tb)
        finally:
            if self._locked:
                self._owner._txn_lock_task = None
                self._owner._txn_lock.release()
                self._locked = False


class Store:
    def __init__(self, persistence=None, name="store", _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.store.json") if self._dir else None
        self._txn_depth = 0
        self._sync_depth = 0        # count of currently-open SYNC-flavor transactions
        self._txn_lock = None       # lazily-created asyncio.Lock; see _Txn.__aenter__
        self._txn_lock_task = None  # which asyncio task currently holds it

    def put(self, key, value):
        """Set key -> value.

        Raises ValueError if `key` stringifies to the same thing as a
        DIFFERENTLY-TYPED key already stored (e.g. put(1, ...) after
        put("1", ...)) — the engine's descriptor storage is string-keyed, so
        without this check the second put() silently overwrote the first
        with no error at all.

        `value` is fully validated for persistence before being stored:
        raises ValueError for two dict keys that would collide after JSON
        stringification, raises TypeError for a dict key that isn't a valid
        JSON key type (e.g. a tuple) or for a value that isn't
        JSON-serializable at all (e.g. a raw `set`) — previously these were
        accepted silently and only failed later, with a raw internals
        error, at save() time. `value` is deep-copied on the way in, tuples
        anywhere inside it are normalized to lists immediately (not only
        after a save/reload), and any NaN/Inf anywhere inside it (including
        nested in a dict, which the engine's own sanitizer does not reach)
        is sanitized to `0.0`.
        """
        skey = str(key)
        this_repr = f"{type(key).__name__}:{key!r}"
        existing = self._spu.desc.get(_KEY_TYPES, {}).get(skey)
        if existing is not None and existing != this_repr:
            raise ValueError(
                f"Store.put: key {key!r} ({type(key).__name__}) collides with an "
                f"already-stored, differently-typed key that also stringifies to "
                f"{skey!r} ({existing}). Store keys are stringified internally — "
                f"use consistent key types, or call store.delete() first if you "
                f"intend to replace it."
            )
        value = prepare_for_persistence(_detach(value), path=f"Store.put({key!r}, ...)")
        self._spu.execute("ADD_DESCRIPTOR", unit=_KEY_TYPES, key=skey, value=this_repr)
        self._spu.execute("ADD_DESCRIPTOR", unit=_UNIT, key=skey, value=value)
        return self

    def get(self, key, default=None):
        if str(key) not in self._spu.desc.get(_UNIT, {}):
            return default
        return _detach(self._spu.desc[_UNIT][str(key)])

    def delete(self, key):
        """Remove key. Raises ValueError for the same cross-type collision
        put() rejects (e.g. delete(1) after put('1', ...)) — previously
        delete() used only str(key), so it could silently remove an entry
        that was put() under a different, non-colliding key type."""
        skey = str(key)
        this_repr = f"{type(key).__name__}:{key!r}"
        existing = self._spu.desc.get(_KEY_TYPES, {}).get(skey)
        if existing is not None and existing != this_repr:
            raise ValueError(
                f"Store.delete: key {key!r} ({type(key).__name__}) does not match "
                f"the type of the key actually stored at {skey!r} ({existing}). "
                f"Use the same key type you put() it with."
            )
        self._spu.execute("REMOVE_DESCRIPTOR", unit=_UNIT, key=skey)
        self._spu.execute("REMOVE_DESCRIPTOR", unit=_KEY_TYPES, key=skey)
        return self

    def keys(self):
        return list(self._spu.desc.get(_UNIT, {}).keys())

    def items(self):
        return _detach(dict(self._spu.desc.get(_UNIT, {})))

    def __contains__(self, key):
        return str(key) in self._spu.desc.get(_UNIT, {})

    def __len__(self):
        return len(self._spu.desc.get(_UNIT, {}))

    def transaction(self):
        """All-or-nothing block. On any exception, every write inside is undone.

        Use `async with store.transaction():` instead of `with` for a block
        that spans await points in async code — it serializes concurrent
        transactions on this same Store instance via a shared asyncio.Lock,
        so two tasks' transactions can no longer interleave on the shared
        engine state."""
        return _Txn(self._spu, self)

    def save(self, path=None):
        """Raises RuntimeError if called while a transaction() is still open
        on this Store — previously save() inside an open transaction wrote
        the UNCOMMITTED in-progress values straight to disk, so a save()
        followed by a rollback left the durable file permanently out of
        sync with the in-memory (correctly rolled-back) state. Save after
        the transaction exits (commits or rolls back) instead."""
        if self._txn_depth > 0:
            raise RuntimeError(
                "Store.save: a transaction() is still open on this Store — save() "
                "would persist uncommitted writes that a rollback could later undo "
                "only in memory, leaving disk permanently out of sync. Call save() "
                "after the transaction block exits."
            )
        p = path or self._path
        if p is None:
            raise ValueError("In-memory Store: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    async def asave(self, path=None):
        """Async save() — see tessera.core.to_thread. Same semantics, same
        exceptions (including the open-transaction RuntimeError above),
        just awaitable instead of blocking the event loop."""
        return await to_thread(self.save, path)

    @classmethod
    def load(cls, name="store", persistence="local", path=None):
        """Loads from `path` if given, else the default (name, persistence)
        location, and binds further saves to that actual path — previously
        an explicit `path` was used only to read, then silently dropped, so
        a subsequent save() went to the default filename instead."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.store.json")
        inst = cls(persistence=persistence, name=name, _spu=safe_load(p))
        inst._path = p
        return inst

    @classmethod
    async def aload(cls, name="store", persistence="local", path=None):
        """Async load() — see tessera.core.to_thread."""
        return await to_thread(cls.load, name, persistence, path)

    @classmethod
    def open(cls, name="store", persistence=None):
        """Load existing state if a save already exists for (name,
        persistence); otherwise create fresh. THE safe entry point for any
        restart path — see COOKBOOK.md Part 2.0. The plain constructor does
        NOT check for an existing save and will silently destroy it on the
        next save() if you construct fresh instead of loading."""
        p = save_path(name, persistence, "store.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(persistence=persistence, name=name)

    @classmethod
    async def aopen(cls, name="store", persistence=None):
        """Async open() — see tessera.core.to_thread."""
        return await to_thread(cls.open, name, persistence)

    @classmethod
    def create(cls, name="store", persistence=None):
        """Create new state; raise FileExistsError if a save already exists
        for (name, persistence). Use this when resuming old state would
        itself be a bug — e.g. provisioning a brand-new entity that must not
        collide with a prior one of the same name."""
        p = save_path(name, persistence, "store.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Store.create: a save already exists for {name!r} at {p} — "
                f"use Store.open() to resume it, or Store.load() if you expect it to exist."
            )
        return cls(persistence=persistence, name=name)

    @classmethod
    async def acreate(cls, name="store", persistence=None):
        """Async create() — see tessera.core.to_thread."""
        return await to_thread(cls.create, name, persistence)

    def __repr__(self):
        return f"Store({self.name!r}, keys={len(self)})"
