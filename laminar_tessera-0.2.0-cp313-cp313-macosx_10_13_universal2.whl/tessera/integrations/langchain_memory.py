"""
tessera.integrations.langchain_memory — EventLog as LangChain chat memory.

Wraps tessera.replay.EventLog as a LangChain `BaseChatMessageHistory` —
durable, offline, zero-dependency chat history for a LangChain chain or
agent, with the same crash-safety properties as every other EventLog-backed
Tessera app.

    from tessera.integrations.langchain_memory import EventLogChatMessageHistory

    history = EventLogChatMessageHistory.open("session-42", persistence="local")
    history.add_user_message("hello")
    history.add_ai_message("hi there")
    history.messages          # [HumanMessage(...), AIMessage(...)]

`langchain-core` is NOT a dependency of the base `tessera` package and is
NOT imported anywhere else in it — this module imports it lazily, inside
_get_class() below, only the first time EventLogChatMessageHistory.open()/
.load()/.create() is actually called. `import
tessera.integrations.langchain_memory` on its own, with no langchain-core
installed at all, must succeed (verified: this module is importable in an
environment where `import langchain_core` raises ImportError) — only
actually constructing the adapter raises, and with a clear message naming
the missing package, not a bare "No module named 'langchain_core'" from
deep inside this file.

Verified against langchain-core 1.8.4's real `BaseChatMessageHistory`
contract (message_to_dict/messages_from_dict for serialization, `clear`
the only truly ABC-enforced abstract method) — not assumed from
documentation. Note langchain-core deprecated `BaseChatMessageHistory`
itself as of 1.6.4 (removal targeted for 2.0.0) in favor of their newer
short-term-memory APIs; this adapter still targets it because it remains
the interface `RunnableWithMessageHistory` and most existing LangChain
memory integrations expect today. If/when it's actually removed upstream,
this module's lazy import will start raising ImportError with the message
below, not silently break.

EventLog is append-only by design (see its own docstring) — there is no
engine opcode to erase persisted history, so clear() is NOT implemented
here as a silent no-op or a fake success; it raises NotImplementedError
with an explicit explanation, because a chain that calls clear() expecting
a fresh start and silently keeps replaying old history would be a far
worse surprise than a loud error. Start a new conversation under a new
name instead.
"""
from ..replay import EventLog

__all__ = ["EventLogChatMessageHistory"]

_EVENT_TYPE = "tessera_chat_message"

_class_cache = {}


def _load_langchain():
    try:
        from langchain_core.chat_history import BaseChatMessageHistory
        from langchain_core.messages import message_to_dict, messages_from_dict
    except ImportError as e:
        raise ImportError(
            "tessera.integrations.langchain_memory requires langchain-core to "
            "be installed (`pip install langchain-core`) — it is not a "
            "dependency of the base tessera package, and is only imported "
            "lazily, right here, the first time EventLogChatMessageHistory is "
            "actually constructed."
        ) from e
    return BaseChatMessageHistory, message_to_dict, messages_from_dict


def _get_class():
    """Builds (once, cached) the real adapter class, which subclasses
    langchain_core's BaseChatMessageHistory — deferred to first use so
    that merely importing this module never requires langchain_core."""
    if "cls" in _class_cache:
        return _class_cache["cls"]

    BaseChatMessageHistory, message_to_dict, messages_from_dict = _load_langchain()

    class _Adapter(BaseChatMessageHistory):
        def __init__(self, log):
            self._log = log

        @property
        def messages(self):
            """Deserializes every stored message fresh on each access —
            EventLog.events() is already a full-history read (deep-copied,
            see its own docstring), so this does no extra I/O beyond that;
            it does NOT cache in Python, so a message appended from
            another process between two .messages reads is picked up."""
            raw = [e["message"] for e in self._log.events()
                   if isinstance(e, dict) and e.get("type") == _EVENT_TYPE]
            return messages_from_dict(raw)

        def add_message(self, message):
            self._log.append({"type": _EVENT_TYPE, "message": message_to_dict(message)})

        def clear(self):
            raise NotImplementedError(
                "EventLogChatMessageHistory.clear(): tessera.replay.EventLog is "
                "append-only by design — there is no way to erase persisted "
                "history. Start a new conversation under a different "
                "name/persistence instead of trying to clear this one."
            )

        def __repr__(self):
            return f"EventLogChatMessageHistory(log={self._log!r})"

    _class_cache["cls"] = _Adapter
    return _Adapter


class EventLogChatMessageHistory:
    """Not constructed directly — use .open()/.load()/.create(), same as
    every other Tessera door. The object actually returned is an instance
    of the real, lazily-built adapter class (a genuine
    langchain_core.chat_history.BaseChatMessageHistory subclass), not of
    this class — this class exists purely as the familiar namespace to
    call those three constructors on without importing langchain_core
    just to find them."""

    def __new__(cls, *args, **kwargs):
        raise TypeError(
            "EventLogChatMessageHistory is not constructed directly — use "
            ".open(name, persistence=...) (or .load()/.create())."
        )

    @staticmethod
    def open(name, persistence=None):
        """Load existing history if a save already exists; otherwise start
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        real_cls = _get_class()
        return real_cls(EventLog.open(name=name, persistence=persistence))

    @staticmethod
    def load(name, persistence="local", path=None):
        real_cls = _get_class()
        return real_cls(EventLog.load(name=name, persistence=persistence, path=path))

    @staticmethod
    def create(name, persistence=None):
        """Create new history; raise FileExistsError if a save already exists."""
        real_cls = _get_class()
        return real_cls(EventLog.create(name=name, persistence=persistence))
