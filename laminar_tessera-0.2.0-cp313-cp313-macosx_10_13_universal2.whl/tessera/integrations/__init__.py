"""
tessera.integrations — adapters onto third-party frameworks.

Nothing here is imported by the base `tessera` package, and nothing in
here is a dependency of it — this subpackage exists so that importing
plain `tessera` never requires, or even attempts to import, any
third-party framework. Each adapter module is responsible for lazily
importing whatever it wraps, only when actually used, with a clear error
if that framework isn't installed (see langchain_memory.py for the first
one).
"""
__all__ = []
