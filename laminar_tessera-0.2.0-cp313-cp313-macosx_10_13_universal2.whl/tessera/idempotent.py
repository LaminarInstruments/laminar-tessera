"""
tessera.idempotent — has this already happened?

A durable, once-per-key check for guarding a real external effect (charging
a card, sending an email, applying a mitigation) against being repeated on
workflow resume after a crash.

    from tessera.idempotent import IdempotentLedger

    ledger = IdempotentLedger.open("charges", persistence="local")
    if not ledger.seen("order-123"):
        charge_card(...)              # the real, non-repeatable effect
        ledger.record("order-123")    # only after it actually happened
    ledger.save()

This formalizes a pattern that already existed twice, hand-rolled, before
this module did: apps/crash_recoverable_order_processor's append-only
charges.log plus a linear scan for the order_id, and
apps/incident_response_coordinator's equivalent mitigation log. Backed by
tessera.store.Store (not a bespoke file format), so it gets Store's own
save()/load()/transaction() for free.

seen()/record() is a check-then-act pattern, not atomic against a
concurrent writer touching the SAME key from a different process at the
same instant — same single-writer caveat as every other door (see
tessera.core.FileLock for closing that gap yourself).
"""
from .store import Store
from .core import to_thread

__all__ = ["IdempotentLedger"]


def _store_key(key):
    if not isinstance(key, str) or not key:
        raise ValueError("IdempotentLedger: key must be a non-empty string.")
    return f"idem:{key}"


class IdempotentLedger:
    def __init__(self, name="idempotent", persistence=None, _store=None):
        self.name = name
        self.persistence = persistence
        self._store = _store if _store is not None else Store(persistence=persistence, name=name)

    def seen(self, key):
        """True if record(key) has ever been called and persisted for this
        key — the signal to SKIP the real effect because it already ran."""
        entry = self._store.get(_store_key(key))
        return bool(entry and entry.get("recorded"))

    def record(self, key, detail=None):
        """Mark `key`'s effect as done, AFTER it actually happened — never
        before, or a crash between record() and the real effect would mark
        something as done that never ran. `detail` (optional, any
        JSON-safe value — same rules as Store.put()) is kept alongside for
        audit, e.g. the amount charged or a trace id.

        Calling record() again for an already-recorded key overwrites
        `detail` but doesn't change seen()'s answer — it was True before
        and remains True. If you need "reject a second record() outright"
        semantics instead, check seen() yourself first."""
        self._store.put(_store_key(key), {"recorded": True, "detail": detail})
        return self

    def detail(self, key):
        """Whatever `detail` was passed to record(key), or None if `key`
        was never recorded (or recorded with no detail)."""
        entry = self._store.get(_store_key(key))
        return entry.get("detail") if entry else None

    def save(self, path=None):
        return self._store.save(path)

    async def asave(self, path=None):
        """Async save() — see tessera.core.to_thread."""
        return await to_thread(self.save, path)

    @classmethod
    def load(cls, name="idempotent", persistence="local", path=None):
        return cls(name=name, persistence=persistence,
                    _store=Store.load(name=name, persistence=persistence, path=path))

    @classmethod
    async def aload(cls, name="idempotent", persistence="local", path=None):
        """Async load() — see tessera.core.to_thread."""
        return await to_thread(cls.load, name, persistence, path)

    @classmethod
    def open(cls, name="idempotent", persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        return cls(name=name, persistence=persistence,
                    _store=Store.open(name=name, persistence=persistence))

    @classmethod
    async def aopen(cls, name="idempotent", persistence=None):
        """Async open() — see tessera.core.to_thread."""
        return await to_thread(cls.open, name, persistence)

    @classmethod
    def create(cls, name="idempotent", persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        return cls(name=name, persistence=persistence,
                    _store=Store.create(name=name, persistence=persistence))

    @classmethod
    async def acreate(cls, name="idempotent", persistence=None):
        """Async create() — see tessera.core.to_thread."""
        return await to_thread(cls.create, name, persistence)

    def __repr__(self):
        return f"IdempotentLedger({self.name!r})"
