from typing import Any, Dict, List, Optional

class WebhookError(RuntimeError): ...

def webhook(url: str, payload: Any, timeout: float = ..., headers: Optional[Dict[str, str]] = ...) -> bytes: ...

__all__: List[str]
