"""
tessera.flows — human-in-the-loop, durably.

Propose an action, let it sit as a pending decision until a human approves
or rejects it — possibly from an entirely different process, possibly after
a restart — then act on the resolution. Built for exactly the shape every
HITL pipeline needs: an agent (or any code) proposes, nothing happens until
a human says yes, and the decision is on record either way.

    from tessera.flows import ApprovalFlow

    flow = ApprovalFlow.open("refund-approvals", persistence="local")
    pid = flow.propose({"action": "refund", "order": "A1", "amount": 42.0})

    # ... anytime later, in this process or a completely different one ...
    flow.pending()                 # [Proposal(id=pid, payload={...}, ...)]
    flow.approve(pid, note="confirmed with customer")
    # or: flow.reject(pid, note="duplicate request")

    flow.get(pid).status           # "approved" / "rejected" / "pending"
    flow.history()                 # every proposal ever made, resolved or not

Durability: each proposal is its own file, not one shared blob for the whole
flow. That matters the moment two DIFFERENT processes propose at the same
time: a single shared JSON file (the pattern every other door uses, backed
by the engine's own save()) would have the second process's whole-file save
silently overwrite the first process's still-pending proposal, since
neither process's in-memory copy knows about the other's. One file per
proposal means two concurrent propose() calls write two different files —
no collision. An approve()/reject() race against the SAME proposal from two
processes at once is still real (see tessera.core.FileLock for callers who
need to close even that gap); that race is now scoped to one proposal's
file, not every pending proposal in the whole flow.
"""
import json
import os
import time
import uuid
import warnings

from .core import persist_dir, to_thread

__all__ = ["ApprovalFlow", "Proposal", "UnknownProposalError", "AlreadyResolvedError"]


class UnknownProposalError(KeyError):
    """Raised by get()/approve()/reject() for a proposal id that was never
    created under this flow name (or was created under a different
    persistence target)."""


class AlreadyResolvedError(RuntimeError):
    """Raised by approve()/reject() when the proposal has already been
    resolved — once a proposal is approved or rejected, that answer is
    final; silently letting a second approve()/reject() overwrite it would
    make the audit trail lie about which decision came first."""


class Proposal:
    """One proposal's full record: id, payload, status, and timestamps.
    Returned by propose()/get()/pending()/history() — never constructed
    directly by callers."""

    def __init__(self, id, payload, status, proposed_at, resolved_at=None, note=None):
        self.id = id
        self.payload = payload
        self.status = status
        self.proposed_at = proposed_at
        self.resolved_at = resolved_at
        self.note = note

    def to_dict(self):
        return {"id": self.id, "payload": self.payload, "status": self.status,
                "proposed_at": self.proposed_at, "resolved_at": self.resolved_at,
                "note": self.note}

    @classmethod
    def _from_dict(cls, d):
        return cls(d["id"], d["payload"], d["status"], d["proposed_at"],
                    d.get("resolved_at"), d.get("note"))

    def __repr__(self):
        return (f"Proposal(id={self.id!r}, status={self.status!r}, "
                f"payload={self.payload!r})")


def _atomic_write_json(path, data):
    """Write-to-temp-then-rename so a reader never sees a half-written
    proposal file — os.replace is atomic on POSIX, the only platform this
    package ships wheels for."""
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}-{uuid.uuid4().hex[:8]}")
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


class ApprovalFlow:
    def __init__(self, name, persistence=None, on_propose=None):
        """`on_propose`, if given, is called as `on_propose(proposal)` with
        the freshly-created, already-durably-persisted Proposal every time
        propose() succeeds — the hook point for e.g. pinging
        tessera.notify.webhook() so a human actually sees that something
        is waiting on them, instead of only finding out by polling
        pending(). Entirely optional: nothing here makes a network call,
        or any kind of call at all, unless you pass one in.

        on_propose runs AFTER the proposal is durably on disk, and any
        exception it raises is caught and turned into a warnings.warn(),
        never a raise out of propose() — a flaky notification (a webhook
        timeout, a typo'd URL) must not make the proposal itself look like
        it failed to save when it didn't."""
        self.name = name
        self.persistence = persistence
        self.on_propose = on_propose
        self._dir = persist_dir(persistence)
        if self._dir is not None:
            self._base = self._dir / f"{name}.flow"
            self._pending_dir = self._base / "pending"
            self._resolved_dir = self._base / "resolved"
            self._pending_dir.mkdir(parents=True, exist_ok=True)
            self._resolved_dir.mkdir(parents=True, exist_ok=True)
        else:
            self._base = None
            self._pending_dir = None
            self._resolved_dir = None
            self._mem = {}   # in-memory fallback: id -> Proposal

    def propose(self, payload):
        """Record a new pending proposal. Returns its id.

        If `on_propose` was set, it's called with the new Proposal AFTER
        this is durably persisted — see __init__'s docstring for why a
        failure there is caught and warned, not raised."""
        pid = uuid.uuid4().hex
        prop = Proposal(pid, payload, "pending", time.time())
        if self._pending_dir is not None:
            _atomic_write_json(self._pending_dir / f"{pid}.json", prop.to_dict())
        else:
            self._mem[pid] = prop
        if self.on_propose is not None:
            try:
                self.on_propose(prop)
            except Exception as e:
                warnings.warn(
                    f"ApprovalFlow({self.name!r}): on_propose callback raised "
                    f"{type(e).__name__}: {e} — proposal {pid!r} is still saved; "
                    f"only the notification failed.",
                    stacklevel=2,
                )
        return pid

    def _load_all(self):
        """Every proposal id this flow has ever seen, deduped, with the
        RESOLVED copy winning over a pending copy of the same id when both
        exist — which happens only if a previous approve()/reject() wrote
        the resolved file but crashed before unlinking the pending one
        (see _resolve()'s own comment). The resolved copy is always the
        more current truth in that case."""
        if self._pending_dir is not None:
            by_id = {}
            for p in self._pending_dir.glob("*.json"):
                prop = Proposal._from_dict(json.load(open(p)))
                by_id[prop.id] = prop
            for p in self._resolved_dir.glob("*.json"):
                prop = Proposal._from_dict(json.load(open(p)))
                by_id[prop.id] = prop   # overwrites any pending-dir copy
            return by_id
        return dict(self._mem)

    def get(self, proposal_id):
        """The current record for `proposal_id`. Raises
        UnknownProposalError if it was never proposed under this flow
        name/persistence."""
        by_id = self._load_all()
        if proposal_id not in by_id:
            raise UnknownProposalError(
                f"ApprovalFlow({self.name!r}): no proposal {proposal_id!r}.")
        return by_id[proposal_id]

    def pending(self):
        """Every proposal still awaiting a decision, oldest first."""
        props = [p for p in self._load_all().values() if p.status == "pending"]
        return sorted(props, key=lambda p: p.proposed_at)

    def history(self):
        """Every proposal ever made under this flow, resolved or not,
        oldest first."""
        return sorted(self._load_all().values(), key=lambda p: p.proposed_at)

    def _resolve(self, proposal_id, status, note):
        prop = self.get(proposal_id)
        if prop.status != "pending":
            raise AlreadyResolvedError(
                f"ApprovalFlow({self.name!r}): proposal {proposal_id!r} was already "
                f"{prop.status!r} at {prop.resolved_at!r} — a decision, once made, "
                f"is final."
            )
        prop.status = status
        prop.resolved_at = time.time()
        prop.note = note
        if self._pending_dir is not None:
            # Write the resolved copy FIRST, durably, before touching the
            # pending one — a crash between these two lines leaves the
            # proposal on disk in BOTH directories, but _load_all() always
            # prefers the resolved copy, so get()/pending()/history() still
            # report it correctly as resolved, and a second approve()/
            # reject() still correctly raises AlreadyResolvedError instead
            # of silently "resolving" it again from the stale pending copy.
            _atomic_write_json(self._resolved_dir / f"{proposal_id}.json", prop.to_dict())
            pending_path = self._pending_dir / f"{proposal_id}.json"
            pending_path.unlink(missing_ok=True)
        else:
            self._mem[proposal_id] = prop
        return prop

    def approve(self, proposal_id, note=None):
        """Resolve a pending proposal as approved. Returns the resolved
        Proposal. Raises AlreadyResolvedError if it was already approved
        or rejected."""
        return self._resolve(proposal_id, "approved", note)

    def reject(self, proposal_id, note=None):
        """Resolve a pending proposal as rejected. Returns the resolved
        Proposal. Raises AlreadyResolvedError if it was already approved
        or rejected."""
        return self._resolve(proposal_id, "rejected", note)

    @classmethod
    def open(cls, name, persistence=None, on_propose=None):
        """THE entry point for any flow — unlike other doors there's no
        separate create()/load() distinction to get wrong: a flow's
        pending/resolved directories either already have proposals in them
        or don't, and either way opening is the same safe operation."""
        return cls(name, persistence=persistence, on_propose=on_propose)

    @classmethod
    async def aopen(cls, name, persistence=None, on_propose=None):
        """Async open() — see tessera.core.to_thread. on_propose itself is
        still called synchronously from inside propose() either way (it
        is not awaited even if it happens to be a coroutine function) —
        this only moves the directory-creation I/O in open() off the
        event loop."""
        return await to_thread(cls.open, name, persistence, on_propose)

    def __repr__(self):
        return f"ApprovalFlow({self.name!r}, pending={len(self.pending())})"
