"""
tessera.core — the shared foundation every door opens onto.

Tessera is NOT a reimplementation. It is the clean front door over the real
engine: `tessera._engine.spu121.SPU121`, the full 121-opcode software SPU.
Every method in every tessera door dispatches to a real SPU opcode — no stubs,
no parallel logic. If you want the raw engine, it is one import away:

    from tessera.core import engine, SPU121

Determinism, crash-safe dispatch, atomic save()/load(), and transactional
rollback are all properties of that engine, inherited here unchanged.
"""
from pathlib import Path

# The engine, shipped compiled (tessera._engine). histogram8 is the SDK's
# binning helper (keeps entropy honest:
# a flat series -> one bin -> low entropy; a spread series -> all bins -> high).
from tessera._engine.spu121 import SPU121, ALL_121 as _ALL_121
# histogram8 is inlined below

def histogram8(samples):
    """Bin a numeric series into 8 equal-width bins -> 8 counts.
    Standard binning (not IP); keeps the compiled-engine dependency minimal."""
    import math as _m
    xs = []
    for v in (samples or []):
        try:
            f = float(v)
            if _m.isfinite(f):
                xs.append(f)
        except (TypeError, ValueError):
            continue
    if not xs:
        return [0] * 8
    lo, hi = min(xs), max(xs)
    if hi == lo:
        return [len(xs)] + [0] * 7
    span = hi - lo
    width = span / 8.0 if _m.isfinite(span) else 0.0
    if not _m.isfinite(span) or span == 0 or width == 0:
        # Extreme-magnitude values (e.g. ~1e308) can make hi - lo itself
        # overflow to inf, then (x - lo) / width become inf / inf = nan, and
        # int(nan) raise ValueError. A DIFFERENT failure mode: span can stay
        # finite but still be so small (e.g. 5e-324, the smallest denormal)
        # that span / 8.0 underflows to exactly 0.0, causing a
        # ZeroDivisionError at bin-index time even though span itself was
        # never zero. Both are caught by checking width itself, not just span.
        #
        # Fall back to binning by UNIQUE VALUE RANK, not by raw sorted
        # INDEX — an index-based rank previously put several EQUAL huge
        # values in different bins purely because of where they landed in
        # the sort, which is wrong: equal readings must always land in the
        # same bin. Ranking the distinct values and assigning every
        # occurrence of a value to its unique value's bin fixes that, and
        # never needs the overflowing/underflowing span at all.
        uniq = sorted(set(xs))
        m = len(uniq)
        bin_of = {v: min(7, (i * 8) // m) for i, v in enumerate(uniq)}
        bins = [0] * 8
        for x in xs:
            bins[bin_of[x]] += 1
        return bins
    bins = [0] * 8
    for x in xs:
        idx = int((x - lo) / width)
        if idx > 7:
            idx = 7
        elif idx < 0:
            idx = 0
        bins[idx] += 1
    return bins


# ------------------------------------------------------------------------
# Shared value-persistence helpers, used by every door that accepts an
# arbitrary caller-supplied value (store.put, workflow step results,
# agents.observe, replay.append). Found via adversarial testing: each door
# had grown its OWN partial version of this validation (or none at all),
# so a fix applied to one (e.g. store.put()'s dict-key-collision check)
# silently did not apply to the others, even though the exact same JSON
# persistence layer underlies all of them.
# ------------------------------------------------------------------------
import math as _math
import json as _json

MAX_ABS_MEASUREMENT = 1e15   # shared with tessera.signals' own check


def normalize_tuples(value):
    """Tuples have no JSON representation — normalize them to lists
    immediately (recursing into dicts/lists too), so the type is
    consistent from the first call, not only after a save/reload."""
    if isinstance(value, (tuple, list)):
        return [normalize_tuples(x) for x in value]
    if isinstance(value, dict):
        return {k: normalize_tuples(v) for k, v in value.items()}
    return value


def deep_sanitize_nan(value):
    """NaN/Inf -> 0.0, recursing into dicts as well as lists/tuples — the
    engine's own shared dispatch sanitizer only recurses into lists/tuples,
    so a NaN nested inside a dict value previously survived untouched and
    could reach json.dump as a literal, nonstandard NaN/Infinity token."""
    if isinstance(value, bool):
        return value
    if isinstance(value, float):
        return value if _math.isfinite(value) else 0.0
    if isinstance(value, (list, tuple)):
        return [deep_sanitize_nan(x) for x in value]
    if isinstance(value, dict):
        return {k: deep_sanitize_nan(v) for k, v in value.items()}
    return value


def validate_json_key_types(value, path="value"):
    """Raise TypeError for a dict key that isn't a type JSON can key by
    (str/int/float/bool/None) — json.dump accepts only these (coercing
    int/float/bool/None to str), raising a raw, late TypeError for
    anything else (e.g. a tuple key) instead."""
    if isinstance(value, dict):
        for k, v in value.items():
            if k is not None and not isinstance(k, (str, int, float, bool)):
                raise TypeError(
                    f"{path}: dict key {k!r} ({type(k).__name__}) is not a valid "
                    f"JSON key type (str, int, float, bool, or None)."
                )
            validate_json_key_types(v, path=f"{path}[{k!r}]")
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            validate_json_key_types(v, path=f"{path}[{i}]")


def validate_no_key_collisions(value, path="value"):
    """Raise ValueError for two dict keys that would collide once both are
    stringified (e.g. {1: 'a', '1': 'b'}) — persistence (JSON) can only
    keep one of them, silently, at whichever key json.dump visits last.
    Recurses into nested dicts/lists, not just the top level."""
    if isinstance(value, dict):
        seen = {}
        for k, v in value.items():
            sk = str(k)
            if sk in seen and seen[sk] != k:
                raise ValueError(
                    f"{path}: keys {seen[sk]!r} and {k!r} both stringify to {sk!r} "
                    f"— persistence (JSON) can only keep one of them. Use one "
                    f"consistent key type."
                )
            seen[sk] = k
            validate_no_key_collisions(v, path=f"{path}[{k!r}]")
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            validate_no_key_collisions(v, path=f"{path}[{i}]")


def validate_json_serializable(value, path="value", allow_nan=True):
    """Catch-all: raise TypeError for anything not representable in JSON at
    all (a set, a custom object, ...) here, with a clear message, instead
    of a raw, late failure inside json.dump at save() time."""
    try:
        _json.dumps(value, allow_nan=allow_nan)
    except (TypeError, ValueError) as e:
        raise TypeError(f"{path}: not JSON-serializable ({e})") from None


def prepare_for_persistence(value, path="value"):
    """The full, composed check+normalize every door should apply to a
    caller-supplied value before storing it: validate key types, validate
    no key collisions, validate overall JSON-serializability (catches
    anything else, e.g. a bare set), then normalize tuples and sanitize
    NaN/Inf (including nested in dicts). Returns the normalized value."""
    validate_json_key_types(value, path=path)
    validate_no_key_collisions(value, path=path)
    validate_json_serializable(value, path=path)
    return normalize_tuples(deep_sanitize_nan(value))


def validate_measurement_magnitude(value, path="value"):
    """Raise ValueError for a numeric reading beyond the magnitude this
    engine's statistics (mean/std/correlation) can handle without losing
    meaning — see tessera.signals' own door-level note. Shared with
    tessera.agents.Field.observe(), which feeds the exact same underlying
    measurement series via the same opcode and was found, via adversarial
    testing, to bypass Signals.measure()'s check entirely when it did."""
    if isinstance(value, float) and _math.isfinite(value) and abs(value) > MAX_ABS_MEASUREMENT:
        raise ValueError(
            f"{path}: reading {value!r} exceeds the supported magnitude "
            f"(abs(value) <= {MAX_ABS_MEASUREMENT:g})."
        )


class FileLock:
    """Opt-in advisory file lock for coordinating multiple PROCESSES around
    the same persisted name — Tessera provides NONE of this by default
    (every door's docstrings are explicit: single-writer, no multi-writer
    coordination). This is a thin, zero-dependency wrapper around POSIX
    advisory locking (fcntl.flock) for callers who need a read-modify-write
    (e.g. Store.open -> mutate -> Store.save) to be atomic across processes
    themselves.

        from tessera.core import FileLock
        from tessera.store import Store

        with FileLock("myapp-counter", persistence="local"):
            store = Store.open("myapp", persistence="local")
            store.put("counter", store.get("counter", 0) + 1)
            store.save()

    Advisory, not mandatory: it only blocks another process that ALSO takes
    this same lock before touching the file. A process that calls save()
    directly, skipping the lock, is not stopped — this coordinates
    cooperating writers, it does not enforce anything on uncooperative ones.

    Not reentrant within one process: a second FileLock on the same path,
    acquired from the SAME process before the first is released, blocks (or
    times out) exactly like a second process would — flock()'s lock belongs
    to the open file description, not the process, so nesting two `with
    FileLock(...)` blocks on the same path deadlocks instead of nesting.

    POSIX only (uses the stdlib fcntl module) — there is no Windows build of
    Tessera to support here, so no portability shim is provided; importing
    this class on a platform without fcntl raises ImportError only when
    actually used (acquire()/__enter__()), not merely by importing
    tessera.core.
    """

    def __init__(self, name, persistence=None, timeout=None):
        d = persist_dir(persistence)
        if d is None:
            raise ValueError(
                "FileLock: requires a real persisted directory — pass "
                "persistence='local' or a directory path, not None/'memory'. "
                "An in-memory lock coordinates nothing, by construction."
            )
        if timeout is not None and not (isinstance(timeout, (int, float))
                                         and not isinstance(timeout, bool) and timeout >= 0):
            raise ValueError(f"FileLock: timeout must be None or a nonnegative number, got {timeout!r}.")
        self.name = name
        self._path = d / f"{name}.lock"
        self._timeout = timeout
        self._fh = None

    def acquire(self):
        """Blocks until the lock is free, or raises TimeoutError if
        `timeout` was set and that many seconds pass first. Safe to call
        again after a previous acquire() on this same instance was
        release()'d; calling it twice without a release() in between is the
        single-process deadlock case documented on the class."""
        import fcntl
        fh = open(self._path, "a")
        if self._timeout is None:
            fcntl.flock(fh, fcntl.LOCK_EX)
            self._fh = fh
            return
        import time
        deadline = time.monotonic() + self._timeout
        while True:
            try:
                fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._fh = fh
                return
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    fh.close()
                    raise TimeoutError(
                        f"FileLock: could not acquire {self._path} within "
                        f"{self._timeout}s — another process is holding it."
                    )
                time.sleep(0.02)

    def release(self):
        """No-op if not currently held (double-release is safe)."""
        if self._fh is not None:
            import fcntl
            fcntl.flock(self._fh, fcntl.LOCK_UN)
            self._fh.close()
            self._fh = None

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release()
        return False

    def __repr__(self):
        held = self._fh is not None
        return f"FileLock({str(self._path)!r}, held={held})"


async def to_thread(fn, *args, **kwargs):
    """Shared helper behind every door's asave()/aload()/aopen()/acreate():
    offload a synchronous, blocking I/O call (file read/write) onto a
    worker thread via asyncio.to_thread, so calling it from async code
    doesn't block the event loop for the duration of the disk operation.

    This does NOT make Tessera's I/O concurrent/parallel-safe — it is the
    exact same synchronous save()/load()/open()/create() underneath, just
    moved off the event loop thread. All the usual single-writer caveats
    (see COOKBOOK.md) still apply."""
    import asyncio
    return await asyncio.to_thread(fn, *args, **kwargs)


_SCHEMA_UNIT_PREFIX = "__tessera_schema__:"   # reserved namespace for a
                                               # door's own schema-version
                                               # marker, separate from any
                                               # unit the door's actual data
                                               # uses — never leaks into a
                                               # door's state().


def schema_version(spu, door_name):
    """The schema version a door's persisted data under `door_name` is
    currently at (0 if never set — covers both a brand-new save and any
    save written before this framework existed)."""
    return spu.desc.get(_SCHEMA_UNIT_PREFIX + door_name, {}).get("version", 0)


def _set_schema_version(spu, door_name, version):
    spu.desc.setdefault(_SCHEMA_UNIT_PREFIX + door_name, {})["version"] = version


def apply_migrations(spu, door_name, migrations):
    """Bring `door_name`'s persisted data up to the latest of `migrations`
    (an ordered list of one-argument functions, each `fn(spu)` mutating
    `spu` in place to move from schema version i to i+1).

    Only the migrations after whatever version is already recorded are
    run — a save already fully migrated replays nothing; an old save
    replays every migration it missed, in order, exactly once. Safe to
    call unconditionally from a door's __init__/load path regardless of
    whether this is a fresh or a loaded instance: each migration function
    MUST be written as a no-op on data that doesn't need it (see the
    example below), so running the full list against empty/fresh state
    costs a few cheap, always-false checks, not a behavior change.

    This generalizes the ad hoc hasattr-sniffing migration
    tessera.agents.Field originally used (pre-v0.1.5 saves stored
    descriptor data under a bare field name before unit namespacing
    existed) into a reusable framework — see agents.py for that migration
    rewritten as the first real, proven caller of this function.

        def _v0_to_v1(spu):
            if "old_key" in spu.desc and "new_key" not in spu.desc:
                spu.desc["new_key"] = spu.desc["old_key"]

        apply_migrations(spu, "my_door:thing-name", [_v0_to_v1])
    """
    current = schema_version(spu, door_name)
    for fn in migrations[current:]:
        fn(spu)
    if migrations:
        _set_schema_version(spu, door_name, len(migrations))


__all__ = ["SPU121", "histogram8",
           "engine", "persist_dir", "save_path", "engine_info",
           "ConcurrentWriteError", "InvalidSaveFileError", "safe_load", "FileLock",
           "schema_version", "apply_migrations", "to_thread"]


def engine():
    """A fresh engine instance. Every tessera door wraps one of these."""
    return SPU121()


def persist_dir(persistence):
    """Resolve a persistence target into a directory (or None for in-memory).

    persistence=None / "memory" / False  -> in-memory only (no file)
    persistence="local" / True           -> ~/.tessera
    persistence=<any other non-empty string/Path>  -> that directory

    Raises ValueError for an empty string — without this check it silently
    resolved to the current working directory, which is almost never what a
    caller meant by "" and was found during adversarial testing to produce a
    save file in whatever directory the process happened to be run from.
    """
    if persistence in (None, False, "memory"):
        return None
    if persistence in (True, "local"):
        base = Path.home() / ".tessera"
    elif persistence == "":
        raise ValueError(
            "persistence='' is not a valid target (it would silently resolve to the "
            "current working directory). Use None for in-memory, 'local' for ~/.tessera, "
            "or a real directory path."
        )
    else:
        base = Path(persistence)
    base.mkdir(parents=True, exist_ok=True)
    return base


def save_path(name, persistence, suffix):
    """Where a door's save file would live for (name, persistence), or None
    for in-memory persistence. Shared by every door's open()/create()."""
    d = persist_dir(persistence)
    return (d / f"{name}.{suffix}") if d is not None else None


class ConcurrentWriteError(RuntimeError):
    """Raised when two writers race the same persisted (name, persistence)
    and the underlying atomic rename collides. This does NOT mean your data
    is safe — the other writer's save may still have partially lost updates
    (see COOKBOOK.md: no multi-writer coordination is provided). It means
    this call, specifically, could not complete, and you get a clear error
    instead of an internals-leaking FileNotFoundError from the compiled
    engine's rename step."""
    pass


class InvalidSaveFileError(ValueError):
    """Raised when a file passed to .load() exists but isn't a valid Tessera
    save (corrupted JSON, or valid JSON in the wrong shape — e.g. a bare
    list instead of the expected object). Previously these failed with a
    raw JSONDecodeError or an internals-leaking AttributeError
    ('list' object has no attribute 'get')."""
    pass


_REQUIRED_SAVE_KEYS = ("_t", "lfsr", "desc", "cache")   # always present in a
                                                          # real save, verified
                                                          # identical across
                                                          # every door's file


def safe_load(path):
    """load() wrapper every door's load() should call instead of
    SPU121.load(path) directly — turns a corrupted or wrong-shape save file
    into a clear, catchable InvalidSaveFileError instead of a raw
    JSONDecodeError/AttributeError leaking the engine's internal shape.

    Also rejects syntactically-valid-but-schema-empty JSON (e.g. "{}") —
    found during adversarial testing: the engine's loader fills in missing
    keys with defaults rather than failing, so a truncated or corrupted file
    that happens to still parse as valid JSON (a bug elsewhere overwriting
    it with "{}", a half-written file, disk corruption that zeroes content)
    silently loaded as "a legitimate empty save," indistinguishable from the
    real thing. A real save always contains the full engine schema; this
    checks for that schema's required keys before trusting the result."""
    import json
    try:
        with open(path) as f:
            raw = json.load(f)
    except FileNotFoundError:
        raise
    except (ValueError, UnicodeDecodeError) as e:
        raise InvalidSaveFileError(
            f"{path} exists but is not valid JSON ({type(e).__name__}: {e})."
        ) from e

    if not isinstance(raw, dict) or not all(k in raw for k in _REQUIRED_SAVE_KEYS):
        raise InvalidSaveFileError(
            f"{path} is valid JSON but missing the expected Tessera save schema "
            f"(required keys: {_REQUIRED_SAVE_KEYS}) — likely corrupted, "
            f"truncated, or not a Tessera save file at all."
        )

    try:
        return SPU121.load(str(path))
    except FileNotFoundError:
        raise
    except (ValueError, AttributeError, TypeError, KeyError) as e:
        raise InvalidSaveFileError(
            f"{path} exists but is not a valid Tessera save file "
            f"({type(e).__name__}: {e})."
        ) from e


def safe_save(spu, path):
    """save() wrapper every door's save() should call instead of
    spu.save(path) directly — turns the concurrent-writer race (two
    processes save()ing the same name at once) from an uncaught,
    internals-leaking FileNotFoundError into a clear, catchable
    ConcurrentWriteError.

    A missing PARENT DIRECTORY raises the same underlying FileNotFoundError
    from the same rename step, but is a completely different situation (no
    other writer involved) — checked for explicitly first and re-raised as
    plain FileNotFoundError, so the two causes are no longer indistinguishable."""
    parent = Path(path).parent
    if not parent.is_dir():
        raise FileNotFoundError(f"{parent} does not exist — create it before calling save().")
    try:
        return spu.save(str(path))
    except FileNotFoundError as e:
        raise ConcurrentWriteError(
            f"Concurrent write collision while saving {path} — another process "
            f"saved to the same persisted name at the same time. Tessera has no "
            f"multi-writer coordination (see COOKBOOK.md); treat this name as "
            f"single-writer, or add your own locking."
        ) from e


def engine_info():
    """What's actually running underneath — proof the front door is real."""
    return {
        "engine": "tessera._engine.spu121.SPU121 (compiled)",
        "opcodes": len(_ALL_121),
        "deterministic": True,
        "dependencies": 0,
        "patent": "pending",
        "author": "Darreck L. Bender II, Founder, Laminar Instruments",
        "contact": "darreck@laminarinstruments.com",
        "url": "https://laminarinstruments.com",
    }
