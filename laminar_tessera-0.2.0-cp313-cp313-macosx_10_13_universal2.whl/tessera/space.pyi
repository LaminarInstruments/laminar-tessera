from pathlib import Path
from typing import Optional, Union

from .core import SPU121
from .agents import Field
from .store import Store
from .graph import Graph
from .signals import Signals
from .workflow import Workflow
from .replay import EventLog
from .baseline import AdaptiveBaseline

class Space:
    name: str
    persistence: Optional[Union[str, bool]]
    agents: Field
    store: Store
    graph: Graph
    signals: Signals
    workflow: Workflow
    replay: EventLog
    baseline: AdaptiveBaseline

    def __init__(self, name: str = ..., persistence: Optional[Union[str, bool]] = ..., _spu: Optional[SPU121] = ...) -> None: ...
    def save(self, path: Optional[str] = ...) -> str: ...
    async def asave(self, path: Optional[str] = ...) -> str: ...

    @classmethod
    def load(cls, name: str = ..., persistence: Union[str, bool] = ..., path: Optional[str] = ...) -> "Space": ...
    @classmethod
    async def aload(cls, name: str = ..., persistence: Union[str, bool] = ..., path: Optional[str] = ...) -> "Space": ...
    @classmethod
    def open(cls, name: str = ..., persistence: Union[str, bool] = ...) -> "Space": ...
    @classmethod
    async def aopen(cls, name: str = ..., persistence: Union[str, bool] = ...) -> "Space": ...
    @classmethod
    def create(cls, name: str = ..., persistence: Union[str, bool] = ...) -> "Space": ...
    @classmethod
    async def acreate(cls, name: str = ..., persistence: Union[str, bool] = ...) -> "Space": ...
    def __repr__(self) -> str: ...

__all__ = ["Space"]
