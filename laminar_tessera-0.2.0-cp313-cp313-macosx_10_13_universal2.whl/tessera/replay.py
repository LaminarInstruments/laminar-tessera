"""
tessera.replay — prove what happened.

A complete, append-only record of every event — so you can rebuild any past
state and show exactly what occurred, and when.

    from tessera.replay import EventLog

    log = EventLog(persistence="local", name="account")
    log.append({"type": "deposit", "amount": 100})
    log.append({"type": "withdraw", "amount": 30})

    def balance(acc, e):
        acc = acc or 0
        return acc + e["amount"] if e["type"] == "deposit" else acc - e["amount"]

    log.reconstruct(balance, initial=0)   # 70 — derived purely from the events

Backed by SPU121: the event list lives in the engine's persisted state and is
written atomically (write + fsync + atomic rename) on every append.
"""
import copy
import json

from .core import (SPU121, persist_dir, save_path, safe_save, safe_load,
                    validate_json_key_types, validate_no_key_collisions,
                    normalize_tuples, to_thread)

__all__ = ["EventLog"]

_EVENTS = "__eventlog__"


class EventLog:
    def __init__(self, persistence=None, name="log", _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.log.json") if self._dir else None

    def append(self, event):
        """Record an event. Durable immediately when persisted.

        `event` is deep-copied and validated as JSON-serializable BEFORE
        being appended to the in-memory log — a caller mutating the dict
        they passed in afterward (or append() rejecting an unserializable
        event) can no longer corrupt or desync this log's history.

        Raises TypeError for a dict key that isn't a valid JSON key type, or
        ValueError for two keys that collide once stringified (e.g.
        {1: 'a', '1': 'b'}) — previously this silently collapsed to one key
        on the very next save/reload, the same class of bug already fixed
        for `store.put()`."""
        validate_json_key_types(event, path="EventLog.append(event)")
        validate_no_key_collisions(event, path="EventLog.append(event)")
        try:
            json.dumps(event, allow_nan=False)
        except (TypeError, ValueError) as e:
            raise TypeError(
                f"EventLog.append: event is not JSON-serializable ({e}) — rejected "
                f"before being added, so a failed append never corrupts the log or "
                f"blocks later valid appends. (NaN/Infinity are rejected here too: "
                f"Python's json module would otherwise silently write the "
                f"nonstandard tokens NaN/Infinity, which a strict JSON reader "
                f"elsewhere can't parse.)"
            ) from None
        self._spu.cache.setdefault(_EVENTS, []).append(normalize_tuples(copy.deepcopy(event)))
        if self._path:
            safe_save(self._spu, self._path)
        return self

    def events(self):
        """Every event, in the order it happened. Deep-copied on the way
        out — mutating a returned event can no longer change stored
        history."""
        return copy.deepcopy(self._spu.cache.get(_EVENTS, []))

    def __len__(self):
        return len(self._spu.cache.get(_EVENTS, []))

    def __iter__(self):
        return iter(self.events())

    def reconstruct(self, reducer, initial=None):
        """Fold the whole history into a state via reducer(state, event).
        The state is DERIVED from the log, never stored directly — that's what
        makes it auditable: the events are the source of truth."""
        state = initial
        for event in self.events():
            state = reducer(state, event)
        return state

    @classmethod
    def load(cls, name="log", persistence="local", path=None):
        """Loads from `path` if given, else the default (name, persistence)
        location. Subsequent append()s save back to the SAME path actually
        loaded from — previously an explicit `path` was used only to read,
        then silently dropped, so appends after an explicit-path load() went
        to the default filename instead, invisible to anyone still reading
        the file actually passed in."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.log.json")
        inst = cls(persistence=persistence, name=name, _spu=safe_load(p))
        inst._path = p
        return inst

    @classmethod
    async def aload(cls, name="log", persistence="local", path=None):
        """Async load() — see tessera.core.to_thread."""
        return await to_thread(cls.load, name, persistence, path)

    @classmethod
    def open(cls, name="log", persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0. Critical for EventLog specifically: a fresh
        construct-then-append silently DESTROYS previously saved events on
        its very next auto-save, not merely fails to resume them."""
        p = save_path(name, persistence, "log.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(persistence=persistence, name=name)

    @classmethod
    async def aopen(cls, name="log", persistence=None):
        """Async open() — see tessera.core.to_thread."""
        return await to_thread(cls.open, name, persistence)

    @classmethod
    def create(cls, name="log", persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "log.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"EventLog.create: a save already exists for {name!r} at {p} — "
                f"use EventLog.open() to resume it, or EventLog.load() if you expect it to exist."
            )
        return cls(persistence=persistence, name=name)

    @classmethod
    async def acreate(cls, name="log", persistence=None):
        """Async create() — see tessera.core.to_thread."""
        return await to_thread(cls.create, name, persistence)

    def __repr__(self):
        return f"EventLog({self.name!r}, events={len(self)})"
