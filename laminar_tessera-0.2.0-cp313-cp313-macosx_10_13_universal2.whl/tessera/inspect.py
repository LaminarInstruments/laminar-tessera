"""
tessera.inspect — what's actually in this save file?

A read-only CLI for looking inside a Tessera save without writing a script.
Every door's save file shares ONE schema — it's the same engine
underneath, whichever door wrote it (see core._REQUIRED_SAVE_KEYS) — so
this is door-agnostic: point it at any .json save, or at an ApprovalFlow's
<name>.flow directory, and it prints a readable breakdown of what's really
persisted there.

    python -m tessera.inspect path/to/something.tessera.json
    python -m tessera.inspect path/to/myapp.space.json
    python -m tessera.inspect path/to/approvals.flow

Intentionally READ-ONLY: this never writes, migrates, or repairs a save —
use the real door classes (Store.load(), Space.load(), ...) for that.
"""
import json
import sys
from pathlib import Path

__all__ = ["inspect_path", "main"]

# Namespaces doors reserve for their own internal bookkeeping, inside
# `desc` — flagged in the summary just so a reader doesn't mistake them
# for application data (see agents.py/store.py for where these come from).
_RESERVED_PREFIXES = (
    "__agent__:", "__agent_gen__:", "__tessera_schema__:",
    "__store__", "__store_key_types__",
)


def _summarize_engine_state(raw, path):
    lines = [f"Tessera engine save: {path}"]
    lines.append(f"  op counter (_t):     {raw.get('_t', 0)}")
    lines.append(f"  prng state (lfsr):   {raw.get('lfsr')}")
    mode = raw.get("mode")
    if mode and mode != "normal":
        lines.append(f"  mode:                {mode}  (!= 'normal')")
    errors = raw.get("errors") or []
    if errors:
        lines.append(f"  errors recorded:     {len(errors)}")

    desc = raw.get("desc") or {}
    lines.append(f"  desc units:          {len(desc)}")
    for unit, fields in sorted(desc.items(), key=str):
        tag = " (reserved)" if any(str(unit).startswith(p) for p in _RESERVED_PREFIXES) else ""
        n = len(fields) if isinstance(fields, dict) else "?"
        lines.append(f"    - {unit!r}{tag}: {n} field(s)")

    cache = raw.get("cache") or {}
    if cache:
        lines.append(f"  cache sections:      {len(cache)}")
        for key, val in sorted(cache.items(), key=str):
            n = len(val) if isinstance(val, (list, dict)) else "?"
            lines.append(f"    - {key!r}: {n} entr(y/ies)")

    meas = raw.get("meas") or {}
    if meas:
        lines.append(f"  measurement series:  {len(meas)}")
        for series, values in sorted(meas.items(), key=str):
            n = len(values) if isinstance(values, list) else "?"
            lines.append(f"    - {series!r}: {n} reading(s)")

    graph = raw.get("graph") or {}
    if graph:
        lines.append(f"  graph nodes:         {len(graph)}")
        lines.append(f"  graph edges:         {raw.get('edges', 0)}")

    fb = raw.get("fb")
    _fb_untouched = (0.8, 0.2, 0.5, 0)   # the engine's own defaults — every
                                          # save has an `fb` dict whether or
                                          # not D4 was ever used, so only
                                          # show it when it's actually moved
                                          # off those defaults
    if fb:
        history = fb.get("history") or []
        if (fb.get("alpha"), fb.get("beta"), fb.get("ema"), len(history)) != _fb_untouched:
            lines.append(
                f"  feedback (D4):       alpha={fb.get('alpha')} beta={fb.get('beta')} "
                f"ema={fb.get('ema')} history_len={len(history)}"
            )

    baseline_ent = raw.get("baseline_ent")
    if baseline_ent is not None:
        lines.append(f"  entropy baseline:    {baseline_ent}")

    return "\n".join(lines)


def _summarize_flow_dir(path):
    pending_dir = path / "pending"
    resolved_dir = path / "resolved"
    pending = sorted(pending_dir.glob("*.json")) if pending_dir.is_dir() else []
    resolved = sorted(resolved_dir.glob("*.json")) if resolved_dir.is_dir() else []
    lines = [
        f"ApprovalFlow directory: {path}",
        f"  pending:  {len(pending)}",
        f"  resolved: {len(resolved)}",
    ]
    by_status = {}
    for p in resolved:
        try:
            d = json.loads(p.read_text())
        except (OSError, ValueError):
            continue
        status = d.get("status", "?")
        by_status[status] = by_status.get(status, 0) + 1
    for status, count in sorted(by_status.items()):
        lines.append(f"    - {status}: {count}")
    return "\n".join(lines)


def inspect_path(path):
    """A human-readable multi-line summary of what's persisted at `path` —
    a single door/Space save file, or an ApprovalFlow directory.

    Raises FileNotFoundError if `path` doesn't exist, ValueError if it
    exists but is neither a recognizable Tessera engine save nor an
    ApprovalFlow directory."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"tessera.inspect: {p} does not exist.")
    if p.is_dir():
        if (p / "pending").is_dir() or (p / "resolved").is_dir():
            return _summarize_flow_dir(p)
        raise ValueError(
            f"tessera.inspect: {p} is a directory but doesn't look like an "
            f"ApprovalFlow directory (no pending/ or resolved/ subdirectory)."
        )
    try:
        raw = json.loads(p.read_text())
    except (OSError, ValueError) as e:
        raise ValueError(f"tessera.inspect: {p} is not readable/valid JSON: {e}") from e
    if not isinstance(raw, dict) or "_t" not in raw or "desc" not in raw:
        raise ValueError(
            f"tessera.inspect: {p} doesn't look like a Tessera engine save "
            f"(missing the expected _t/desc keys)."
        )
    return _summarize_engine_state(raw, p)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        print("usage: python -m tessera.inspect <path>", file=sys.stderr)
        return 2
    try:
        print(inspect_path(argv[0]))
    except (FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
