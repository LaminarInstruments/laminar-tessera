"""
tessera.baseline — learn what normal looks like, and let it move.

`signals.anomalies()` compares a new reading to a STATIC population mean/std
computed over a series' ENTIRE history. That's wrong for anything that
genuinely drifts over time — a server's normal latency creeping up over
weeks as load grows, a patient's resting heart rate changing as they get
fitter — because a fixed historical average either chases noise (if the
window is short) or lags badly behind a real, legitimate regime change (if
it's long). `AdaptiveBaseline` tracks a MOVING baseline instead, via
exponential feedback, and can tell you whether it's settling, still
drifting, or flapping unstably.

    from tessera.baseline import AdaptiveBaseline

    b = AdaptiveBaseline.open("server-1-latency", persistence="local")
    b.set_rate(alpha=0.9, beta=0.1)      # higher beta = adapts faster, noisier
    for reading in readings:
        b.learn(reading)
    b.value()              # the current learned baseline
    b.convergence_rate()   # how much it's still moving (near 0 = settled)
    b.oscillating()        # is it flapping instead of settling?
    b.save()

This is backed by real engine capability that existed before this module did
— adaptive feedback/EMA for the moving baseline, and entropy-baseline
tracking for the drift half below. This module is their first public door.

One instance tracks ONE scalar baseline (the engine's feedback state is a
single alpha/beta/ema triple, not a dict keyed by series name — confirmed by
direct probing, not assumed). Open a separate named AdaptiveBaseline per
thing you want to track independently, the same way you'd open a separate
Store per logical dataset.
"""
import math

from .core import SPU121, persist_dir, save_path, safe_save, safe_load, histogram8, to_thread

__all__ = ["AdaptiveBaseline", "BaselineSet"]


def _require_finite(name, value):
    if not (isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)):
        raise ValueError(f"AdaptiveBaseline.set_rate: {name} must be a finite number, got {value!r}.")


class AdaptiveBaseline:
    def __init__(self, name, persistence=None, _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.baseline.json") if self._dir else None

    # -- the moving baseline (adaptive feedback/EMA) ---------------------------
    def set_rate(self, alpha, beta):
        """How fast the baseline adapts: new_baseline = alpha*old + beta*reading.
        Higher beta = faster-adapting, noisier. Higher alpha = slower,
        steadier. Engine defaults to (0.8, 0.2) with an initial value of 0.5
        until you call this.

        Raises ValueError if either coefficient isn't finite — the shared
        dispatch sanitizer silently turns a NaN into 0.0 before the engine
        ever sees it, which used to set that coefficient to exactly 0 with
        no error and no indication the call was ever invalid."""
        _require_finite("alpha", alpha)
        _require_finite("beta", beta)
        return self._spu.execute("ADJUST_ALPHA_BETA", alpha=float(alpha), beta=float(beta))

    def learn(self, value):
        """Feed one new reading into the learned baseline. Returns the
        updated baseline."""
        return self._spu.execute("ADD_FEEDBACK", reward=float(value))

    def learn_many(self, values):
        """Feed a sequence of readings in order. Returns the final baseline
        after folding through all of them."""
        return self._spu.execute("BUILD_FEEDBACK_CHAIN", rewards=[float(v) for v in values])

    def value(self):
        """The current learned baseline (0.5 if learn() has never been called)."""
        return self._spu.execute("RECALCULATE_CONVERGENCE")

    def convergence_rate(self):
        """Mean absolute change over the last ~10 updates. Near zero means
        the baseline has settled; large means it's still moving a lot."""
        return self._spu.execute("COMPUTE_CONVERGENCE_RATE")

    def oscillating(self, threshold=0.5):
        """True if the baseline's recent updates are flapping up and down
        rather than settling in one direction (DETECT_OSCILLATION's raw
        sign-change fraction exceeds `threshold`) — a sign the learning
        rate is too aggressive for this series, or the underlying signal
        is genuinely unstable, not just trending."""
        return self._spu.execute("DETECT_OSCILLATION") > threshold

    def trend(self):
        """A smoothed (3-point trailing average) view of the full feedback
        history — the recent trend with single-reading noise damped out."""
        return self._spu.execute("SMOOTH_FEEDBACK_CURVE")

    def nudge(self, delta):
        """Manually shift the baseline by delta. For when you know a
        deliberate change just happened (a deploy, a dosage change) and
        want the baseline to reflect it immediately instead of catching up
        over several learn() calls."""
        return self._spu.execute("INJECT_TEMPORAL_PERTURBATION", delta=float(delta))

    def amplify(self, gain):
        """Manually scale the baseline by `gain`. A deliberate override,
        not something learn() does on its own."""
        return self._spu.execute("AMPLIFY_FEEDBACK_SIGNAL", gain=float(gain))

    def attenuate(self, factor):
        """Manually scale the baseline by `factor` (typically 0..1)."""
        return self._spu.execute("ATTENUATE_FEEDBACK_NOISE", factor=float(factor))

    # -- entropy drift against a ratcheting baseline --------------------------
    def track_entropy(self, values):
        """Compute this batch's entropy and ratchet the tracked entropy
        baseline forward to it. Returns True if entropy dropped or held
        relative to the PREVIOUS baseline (things got more orderly, or
        stayed the same) — False if it got more disordered. Either way,
        the baseline moves to the new value, so this is a step-over-step
        check, not a comparison against a fixed historical "normal."

        Raises ValueError for an empty batch — an empty `values` hashes to
        an all-zero histogram (zero entropy), which used to silently
        ratchet the tracked baseline down to 0.0 and report "improvement"
        even though nothing was actually observed."""
        if not values:
            raise ValueError("AdaptiveBaseline.track_entropy: values must be nonempty.")
        return self._spu.execute("ASSERT_ENTROPY_DROP", data=histogram8(values))

    def entropy_drift(self, values):
        """This batch's entropy minus the tracked entropy baseline —
        read-only, does NOT move the baseline. Positive = more disordered
        than baseline; negative = less. Raises nothing if no baseline is
        set yet (returns H - None treated as 0.0 by the engine).

        Raises ValueError for an empty batch, for the same reason
        track_entropy() does — an empty histogram's entropy (0.0) isn't a
        real reading to compare against the baseline."""
        if not values:
            raise ValueError("AdaptiveBaseline.entropy_drift: values must be nonempty.")
        return self._spu.execute("COMPARE_ENTROPY_BASELINES", data=histogram8(values))

    def baseline_entropy(self):
        """The current tracked entropy baseline, or None if track_entropy()
        has never been called."""
        return self._spu.baseline_ent

    # -- persistence ------------------------------------------------------------
    def save(self, path=None):
        p = path or self._path
        if p is None:
            raise ValueError(
                "In-memory AdaptiveBaseline: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    async def asave(self, path=None):
        """Async save() — see tessera.core.to_thread."""
        return await to_thread(self.save, path)

    @classmethod
    def load(cls, name, persistence="local", path=None):
        """Loads from `path` if given, else the default (name, persistence)
        location, and binds further saves to that actual path — previously
        an explicit `path` was used only to read, then silently dropped, so
        a subsequent save() went to the default filename instead."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.baseline.json")
        inst = cls(name, persistence=persistence, _spu=safe_load(p))
        inst._path = p
        return inst

    @classmethod
    async def aload(cls, name, persistence="local", path=None):
        """Async load() — see tessera.core.to_thread."""
        return await to_thread(cls.load, name, persistence, path)

    @classmethod
    def open(cls, name, persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        p = save_path(name, persistence, "baseline.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(name, persistence=persistence)

    @classmethod
    async def aopen(cls, name, persistence=None):
        """Async open() — see tessera.core.to_thread."""
        return await to_thread(cls.open, name, persistence)

    @classmethod
    def create(cls, name, persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "baseline.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"AdaptiveBaseline.create: a save already exists for {name!r} at {p} — "
                f"use .open() to resume it, or .load() if you expect it to exist.")
        return cls(name, persistence=persistence)

    @classmethod
    async def acreate(cls, name, persistence=None):
        """Async create() — see tessera.core.to_thread."""
        return await to_thread(cls.create, name, persistence)

    def __repr__(self):
        return f"AdaptiveBaseline({self.name!r}, value={self.value():.4g})"


_SET_SEP = "--"   # separates a BaselineSet's name from a member key in the
                  # on-disk filename — found while retrofitting
                  # apps/incident_response_coordinator's hand-rolled
                  # {service: AdaptiveBaseline.open(f"baseline-{service}")}
                  # dict, which is exactly what BaselineSet replaces.


class BaselineSet:
    """N independent AdaptiveBaseline instances, one per key, managed under
    ONE name — for tracking the same kind of thing (latency, heart rate)
    separately per entity (per service, per patient) without hand-rolling a
    dict of AdaptiveBaseline.open() calls yourself.

    One AdaptiveBaseline instance is bound to exactly one scalar baseline
    (the engine's feedback state is a single alpha/beta/ema triple, not a
    dict keyed by series — see AdaptiveBaseline's own docstring). A
    BaselineSet is still N separate engines under the hood, one per key —
    this class only saves you the bookkeeping of naming and restoring them.

        from tessera.baseline import BaselineSet

        latency = BaselineSet.open("svc-latency", persistence="local")
        latency.learn("api", 42.0)
        latency.learn("db", 310.0)
        latency.value("api")        # 42.0-ish, tracked independently of db
        latency.save()

    .open() is the safe entry point on every restart: it restores every key
    that was EVER learn()'d under this name, not just the ones touched again
    this run — a lazy "create on first access" design would otherwise make
    .keys() return an incomplete set after a restart, wrong the moment a
    caller iterates all known keys (e.g. to report on every service)
    instead of only the one that happened to get a learn() call this run.
    """

    def __init__(self, name, persistence=None):
        self.name = name
        self.persistence = persistence
        self._dir = persist_dir(persistence)
        self._members = {}

    def _require_key(self, key):
        if not isinstance(key, str) or not key:
            raise ValueError("BaselineSet: key must be a non-empty string.")
        return key

    def _member_name(self, key):
        return f"{self.name}{_SET_SEP}{self._require_key(key)}"

    def __contains__(self, key):
        return key in self._members

    def __len__(self):
        return len(self._members)

    def __getitem__(self, key):
        """The AdaptiveBaseline for `key`, creating it (fresh, in-memory
        until the next save()) the first time this key is seen."""
        self._require_key(key)
        if key not in self._members:
            self._members[key] = AdaptiveBaseline.open(
                self._member_name(key), persistence=self.persistence)
        return self._members[key]

    def keys(self):
        return list(self._members.keys())

    def values(self):
        return list(self._members.values())

    def items(self):
        return list(self._members.items())

    def learn(self, key, value):
        """Feed one new reading into the baseline tracked under `key`."""
        return self[key].learn(value)

    def value(self, key):
        """The current learned baseline for `key`."""
        return self[key].value()

    def save(self):
        """Save every member this process has touched. Members never
        learn()'d or value()'d this run (and so never created via
        __getitem__) are untouched — nothing to save, nothing lost; .open()
        will still find them next time via the on-disk scan."""
        if self._dir is None:
            raise ValueError(
                "In-memory BaselineSet: construct with persistence='local' "
                "to use save().")
        for member in self._members.values():
            member.save()
        return self

    async def asave(self):
        """Async save() — see tessera.core.to_thread."""
        return await to_thread(self.save)

    @classmethod
    def open(cls, name, persistence=None):
        """THE safe entry point for any restart path (see COOKBOOK.md Part
        2.0): restores every key ever saved under this name by scanning the
        persistence directory for '<name>--<key>.baseline.json' files, not
        just whichever key the next learn()/value() call happens to touch."""
        inst = cls(name, persistence=persistence)
        if inst._dir is not None:
            prefix = f"{name}{_SET_SEP}"
            suffix = ".baseline.json"
            for p in inst._dir.glob(f"{prefix}*{suffix}"):
                key = p.name[len(prefix):-len(suffix)]
                inst._members[key] = AdaptiveBaseline.load(
                    f"{prefix}{key}", persistence=persistence)
        return inst

    @classmethod
    async def aopen(cls, name, persistence=None):
        """Async open() — see tessera.core.to_thread."""
        return await to_thread(cls.open, name, persistence)

    def __repr__(self):
        return f"BaselineSet({self.name!r}, keys={self.keys()!r})"
