"""
tessera.notify — the one place Tessera makes a network call, and only when
you ask it to.

Every other door in this package is deliberately offline — no network I/O,
anywhere, ever (see the Cookbook/README: "All data stays local. No cloud.
No server."). tessera.notify.webhook() is the single, opt-in exception to
that. Nothing in Tessera calls it automatically; you wire it in yourself,
typically as an ApprovalFlow's on_propose callback, when you actually want
a pending proposal to also ping Slack/a pager/wherever a human will see it.

    from tessera.flows import ApprovalFlow
    from tessera.notify import webhook

    flow = ApprovalFlow.open(
        "refund-approvals", persistence="local",
        on_propose=lambda p: webhook("https://hooks.example.com/...", {
            "text": f"New refund proposal {p.id}: {p.payload}"
        }),
    )

webhook() is stdlib-only (urllib.request) — no `requests`, no third-party
dependency, consistent with the rest of the package.

webhook() itself raises normally (WebhookError) on a real failure — a
connection error, a timeout, or a non-2xx response. It is NOT fire-and-
forget on its own. The fire-and-forget behavior lives one layer up, in
ApprovalFlow.propose()'s on_propose wrapper, which catches whatever an
on_propose callback raises (including a WebhookError from this function)
so a flaky notification can never make propose() itself look like it
failed — see ApprovalFlow's own docstring for that half of the contract.
"""
import json
import urllib.error
import urllib.request

__all__ = ["webhook", "WebhookError"]


class WebhookError(RuntimeError):
    """Raised by webhook() when the request fails outright (a network
    error or timeout) or the server responds with a non-2xx status — wraps
    whichever underlying urllib exception fired, so callers get one
    consistent error type regardless of the specific failure mode."""


def webhook(url, payload, timeout=5.0, headers=None):
    """POST `payload` (any JSON-serializable value) as JSON to `url`.

    Raises ValueError up front if `url` isn't an http:// or https:// URL —
    urllib.request would otherwise happily accept a `file://` URL (or one
    with no scheme at all) and read or write a local file instead of
    making a network call, which is not what "webhook" means and would
    silently defeat the entire point of this being the one explicit,
    auditable network door in the package.

    Raises WebhookError for a connection error, a timeout, or a non-2xx
    HTTP response. Returns the response body (bytes) on success."""
    if not isinstance(url, str) or not url.lower().startswith(("http://", "https://")):
        raise ValueError(
            f"webhook: url must be an http:// or https:// URL, got {url!r}."
        )
    if not (isinstance(timeout, (int, float)) and not isinstance(timeout, bool) and timeout > 0):
        raise ValueError(f"webhook: timeout must be a positive number, got {timeout!r}.")

    body = json.dumps(payload).encode("utf-8")
    req_headers = {"Content-Type": "application/json"}
    req_headers.update(headers or {})
    req = urllib.request.Request(url, data=body, method="POST", headers=req_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", resp.getcode())
            data = resp.read()
            if not (200 <= status < 300):
                raise WebhookError(f"webhook: {url} responded with status {status}.")
            return data
    except urllib.error.HTTPError as e:
        raise WebhookError(f"webhook: {url} responded with status {e.code}: {e.reason}") from e
    except urllib.error.URLError as e:
        raise WebhookError(f"webhook: could not reach {url}: {e.reason}") from e
