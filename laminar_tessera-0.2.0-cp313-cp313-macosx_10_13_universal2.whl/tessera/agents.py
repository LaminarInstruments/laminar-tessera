"""
tessera.agents — remember & decide.

Watch what's happening, try a choice safely on a branch without touching live
state, keep the one you want, survive a crash, and replay the history.

    from tessera.agents import Field, Program

    agent = Field("warehouse", persistence="local")
    agent.observe({"stock": 120, "demand": 145})

    branch = agent.fork()                       # explore a future in isolation
    branch.run(Program("restock"), quantity=100)
    agent.commit(branch)                         # keep that choice
    agent.save()                                 # survives a crash, replays exactly

Backed by SPU121: observations are descriptors + measurements, fork is an
isolated engine copy, save/load are the engine's atomic durable persistence,
and the event log rides in the engine's own persisted state.
"""
import copy
import hashlib
import warnings

from .core import (SPU121, persist_dir, save_path, safe_save, safe_load, _ALL_121,
                    prepare_for_persistence, validate_measurement_magnitude,
                    apply_migrations, to_thread)

__all__ = ["Field", "Program", "program"]

_EVENTS = "__events__"       # event log, kept in the engine's persisted cache
_WF_DONE = "__wf_done__"
_UNIT_PREFIX = "__agent__:"  # reserved namespace, independent of the Field's
                             # user-facing `name` — a Space whose name happened
                             # to equal another door's reserved internal unit
                             # (e.g. Store's "__store__") used to collide with
                             # that door's descriptors, since Field wrote
                             # straight under the raw `name` with no namespace
                             # of its own.
_IDENTITY_KEY = "__field_identity__"  # records the ORIGINAL logical name a
                             # Field was constructed/saved with, inside its
                             # own persisted state — load(name=..., path=...)
                             # honors this over a possibly-mismatched `name`
                             # argument, so an explicit-path load can't
                             # silently return an empty view of real data.
_GEN_UNIT_PREFIX = "__agent_gen__:"  # a counter bumped only by writes to
                             # THIS field's own unit (observe()/run()) — a
                             # separate reserved unit, not a key inside
                             # self._unit, so it never leaks into state().
                             # fork()/commit() compare THIS counter, not the
                             # engine-wide op count (self._spu._t), so
                             # unrelated door activity on store/signals/
                             # replay between fork() and commit() (e.g. from
                             # a workflow run in between) no longer makes a
                             # perfectly fresh commit look "stale" — found
                             # via building apps/incident_response_coordinator,
                             # which needed force=True for exactly this reason
                             # before this fix.


def _program_revision(program):
    """A stable identifier for THIS Program's actual body — distinct
    definitions sharing the same `name` get distinct revisions, so a run
    event can tell them apart instead of looking identical for two
    different implementations."""
    h = hashlib.sha256()
    h.update(program.name.encode())
    if program.fn is not None:
        code = getattr(program.fn, "__code__", None)
        if code is not None:
            # co_code alone is the bytecode OPCODES only — two bodies that
            # differ only in a literal (e.g. a string constant) compile to
            # identical co_code with different co_consts, so both are
            # included here.
            h.update(code.co_code)
            h.update(repr(code.co_consts).encode())
            h.update(repr(code.co_names).encode())
        else:
            h.update(repr(program.fn).encode())
    else:
        h.update(repr(program.steps).encode())
    return h.hexdigest()[:16]


def _validate_observation_keys(observations):
    """Reject two distinct keys that would collide once both are coerced to
    str (e.g. 3 and "3") — without this, the second silently overwrote the
    first with no error, and len(state()) looked wrong with no indication
    why."""
    seen = {}
    for k in observations:
        sk = str(k)
        if sk in seen and seen[sk] != k:
            raise ValueError(
                f"Field.observe: keys {seen[sk]!r} and {k!r} both stringify to "
                f"{sk!r} — descriptor storage is string-keyed, so only one of "
                f"them could ever be kept. Use one consistent key type."
            )
        seen[sk] = k


class Program:
    """A named thing an agent can run.

    Three honest forms, in order of power:
      Program("restock")                         -> records the intent + applies
                                                    any kwargs as state (replayable)
      Program("restock", fn=lambda f, **kw: ...) -> a Python function over the field
      Program("restock", steps=[("ADD_MEASUREMENT", {"series": "x"}), ...])
                                                 -> an explicit opcode sequence
    """
    def __init__(self, name, fn=None, steps=None):
        self.name = name
        self.fn = fn
        self.steps = list(steps or [])

    def __repr__(self):
        return f"Program({self.name!r})"


def program(fn):
    """Decorator: turn a function into a Program named after it."""
    return Program(fn.__name__, fn=fn)


class Field:
    """An agent's unified state — memory, relationships, and decisions in one."""

    def __init__(self, name, persistence=None, _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.tessera.json") if self._dir else None
        self._unit = _UNIT_PREFIX + name
        self._gen_unit = _GEN_UNIT_PREFIX + name
        if not hasattr(self._spu, "_tessera_origin"):
            import uuid
            self._spu._tessera_origin = uuid.uuid4().hex
        if not hasattr(self._spu, "_tessera_instance_id"):
            import uuid
            self._spu._tessera_instance_id = uuid.uuid4().hex
        # Schema migration, via the general tessera.core framework: a save
        # from before unit-namespacing existed (pre-v0.1.5) stored
        # descriptor data directly under the bare `name` (no `__agent__:`
        # prefix) — found via adversarial testing that simply upgrading the
        # package silently emptied state() for every pre-existing Field,
        # with no error at all. _migrate_v0_bare_name_to_namespaced_unit
        # copies it into the namespaced unit once, non-destructively (the
        # old bare unit is left in place, just unused going forward). This
        # was originally a bespoke hasattr-style check inline here; it's
        # now registered as this Field's v0->v1 migration, scoped per
        # field name (schema progress is tracked per-name, same as the
        # generation counter above, since multiple Fields can share one
        # engine inside a Space).
        apply_migrations(self._spu, f"agents:{name}",
                          [self._migrate_v0_bare_name_to_namespaced_unit])

    def _migrate_v0_bare_name_to_namespaced_unit(self, spu):
        """v0 -> v1 for this Field's name: see the call site in __init__.
        Required to be a no-op when there's nothing to migrate (a fresh
        Field, or one already on the namespaced unit) — apply_migrations()
        runs every door's migrations unconditionally on construction, so
        this must tolerate being called against state that doesn't need
        it."""
        if (self._unit not in spu.desc
                and self.name in spu.desc and spu.desc.get(self.name)):
            spu.desc[self._unit] = dict(spu.desc[self.name])

    def _current_gen(self):
        return self._spu.desc.get(self._gen_unit, {}).get("value", 0)

    def _bump_gen(self):
        cur = self._current_gen()
        self._spu.desc.setdefault(self._gen_unit, {})["value"] = cur + 1

    # -- observe --------------------------------------------------------------
    def observe(self, observations):
        """Record what the agent sees. Scalars become both a descriptor (the
        current value) and a measurement (the running series, for stats).

        `observations` is materialized into a list ONCE up front — passing a
        one-shot iterator used to leave the logged event payload empty,
        since the same iterator was exhausted building state first and had
        nothing left when the log tried to read it again.

        Raises ValueError up front (before touching any state) for two
        distinct keys that would collide once stringified, for a value
        that fails conversion (e.g. an int too large for float()), for a
        numeric value with `abs(value) > 1e15` (observe() feeds the exact
        same shared measurement series `signals.stats()` reads — found via
        adversarial testing that this bypassed Signals.measure()'s own
        magnitude check entirely, since the two doors share the same
        underlying opcode), or for a value that isn't fully JSON-safe
        (mirrors store.put()'s validation: a colliding nested dict key, a
        dict key of an invalid JSON type, or a plain non-serializable
        value like a set) — all values are validated/converted BEFORE any
        descriptor or measurement is written, so a failure partway through
        no longer leaves a partial, unlogged mutation behind."""
        pairs = list(dict(observations).items())
        _validate_observation_keys(dict(pairs))
        prepared = []
        for key, value in pairs:
            is_numeric = isinstance(value, (int, float)) and not isinstance(value, bool)
            fval = None
            if is_numeric:
                try:
                    fval = float(value)
                except (OverflowError, ValueError) as e:
                    raise ValueError(f"Field.observe: value for {key!r} ({value!r}) is not a valid float: {e}") from None
                validate_measurement_magnitude(fval, path=f"Field.observe: value for {key!r}")
            else:
                value = prepare_for_persistence(value, path=f"Field.observe: value for {key!r}")
            prepared.append((str(key), value, is_numeric, fval))

        for skey, value, is_numeric, fval in prepared:
            self._spu.execute("ADD_DESCRIPTOR", unit=self._unit, key=skey, value=value)
            if is_numeric:
                self._spu.execute("ADD_MEASUREMENT", series=skey, value=fval)
        self._bump_gen()
        self._log("observe", dict(pairs))
        return self

    def state(self):
        """The agent's current view: key -> latest value."""
        return copy.deepcopy(self._spu.desc.get(self._unit, {}))

    # -- branch / decide ------------------------------------------------------
    def fork(self):
        """An isolated copy to explore a future on. Changes here do NOT touch
        this field until you commit() them back.

        A true deep copy — not to_dict()/from_dict(), which shares the engine's
        live dicts (that round-trip is only independent once it goes through
        JSON on disk). Tagged with the generation `self` was at when forked
        (a counter bumped only by observe()/run() calls against THIS field's
        OWN unit, not the engine-wide op count — so unrelated activity on
        other doors sharing the same Space between fork() and commit() does
        NOT make a fresh commit look stale; see _GEN_UNIT_PREFIX), AND with
        `self`'s own instance id — a later commit() can only meaningfully
        compare generations against the EXACT object a branch was directly
        forked from (two independent objects' counts aren't comparable).
        Committing a branch of a branch (`field.fork().fork()`) directly onto
        the ORIGINAL field skips the generation check (there's no direct
        parent-child relationship to compare), falling back to just the
        lineage/origin check — found via adversarial testing that comparing
        the grandchild's generation against the wrong ancestor's count
        produced a false-positive "stale" rejection for this legitimate
        multi-level fork pattern. Chain commits (leaf -> intermediate ->
        root) get the full staleness check at every hop."""
        import uuid
        twin = copy.deepcopy(self._spu)
        twin._tessera_fork_gen = self._current_gen()
        twin._tessera_fork_origin = self._spu._tessera_origin
        twin._tessera_fork_parent_id = self._spu._tessera_instance_id
        twin._tessera_instance_id = uuid.uuid4().hex  # the twin is its OWN instance now
        f = Field(self.name, persistence=None, _spu=twin)
        return f

    def run(self, program, **kwargs):
        """Run a Program against this field, mutating its state."""
        results = None
        if program.fn is not None:
            result = program.fn(self, **kwargs)
            if result is not None:
                warnings.warn(
                    f"Program {program.name!r}: fn returned {result!r}, but an "
                    f"fn-form Program's return value is discarded, not applied to "
                    f"the field — call field.observe(...) inside fn if you want "
                    f"it recorded.",
                    stacklevel=2,
                )
        elif program.steps:
            # Preflight every opcode name before running ANY of them — an
            # unknown opcode used to only fail partway through, after
            # earlier steps' real effects had already happened with no run
            # event ever recorded for them (execute() raises immediately for
            # an unknown opcode, which previously skipped the _log() call
            # below entirely).
            unknown = [op for op, _ in program.steps if op not in _ALL_121]
            if unknown:
                raise ValueError(f"Program {program.name!r}: unknown opcode(s) {unknown!r} — nothing executed.")
            results = [self._spu.execute(op, **{**kw, **kwargs}) for op, kw in program.steps]
        else:
            # no body: record the intent and fold kwargs into state — still a
            # real, replayable state change, not a no-op.
            for key, value in kwargs.items():
                self._spu.execute("ADD_DESCRIPTOR", unit=self._unit, key=str(key), value=value)
        payload = {"program": program.name, "rev": _program_revision(program), **kwargs}
        if results is not None:
            payload["results"] = results   # per-operation results, so a caller can
                                            # check e.g. a RESTORE_CHECKPOINT's bool
                                            # without run() imposing failure semantics
        self._bump_gen()
        self._log("run", payload)
        return self

    def commit(self, branch=None, force=False):
        """Keep a decision. With a branch, adopt the future you explored on it.

        Raises ValueError if `branch` didn't come from forking THIS field's
        engine (a different Space/Field entirely was previously accepted
        silently), or if this field has changed since `branch` was forked
        from it (previously a stale branch's commit() clobbered the ENTIRE
        engine — including unrelated writes made on the live field after
        the fork — with no warning). Pass force=True for an explicit,
        deliberate whole-world replacement regardless of staleness.

        Mutates the engine IN PLACE rather than rebinding self._spu. Inside a
        Space, every door shares the exact same spu object by reference;
        rebinding here would silently detach this Field from that shared
        state, so Space.save() would go on serializing the stale, pre-commit
        engine while this Field's own .state()/.history() correctly showed
        the committed branch — a real bug, caught by testing commit() inside
        a shared Space rather than only a standalone Field."""
        if branch is not None:
            branch_origin = getattr(branch._spu, "_tessera_fork_origin", None)
            if not force and branch_origin != getattr(self._spu, "_tessera_origin", None):
                raise ValueError(
                    "Field.commit: branch did not come from fork()ing this field's "
                    "engine (different Space/Field) — refusing to merge unrelated "
                    "state. Pass force=True to override."
                )
            parent_id = getattr(branch._spu, "_tessera_fork_parent_id", None)
            is_direct_child = (parent_id is not None
                               and parent_id == getattr(self._spu, "_tessera_instance_id", None))
            fork_gen = getattr(branch._spu, "_tessera_fork_gen", None)
            current_gen = self._current_gen()
            if not force and is_direct_child and fork_gen is not None and fork_gen != current_gen:
                raise ValueError(
                    f"Field.commit: this field's own state advanced (generation "
                    f"{current_gen}) since branch was forked (generation {fork_gen}) "
                    f"— committing now would silently discard whatever changed in "
                    f"between. Re-fork from the current state, or pass force=True "
                    f"for an explicit whole-world replacement."
                )
            self._spu.__dict__.update(copy.deepcopy(branch._spu.__dict__))
        return self

    # -- durability & replay --------------------------------------------------
    def save(self, path=None):
        """Persist durably (atomic write + fsync). Survives a crash.

        Records this Field's own logical `name` inside the saved state
        itself — load() with an explicit `path` honors THAT over its `name`
        argument, so loading a file saved under a different name can't
        silently return an empty view of real data (see load())."""
        self._spu.execute("ADD_DESCRIPTOR", unit=_IDENTITY_KEY, key="name", value=self.name)
        p = path or self._path
        if p is None:
            raise ValueError(
                "This Field is in-memory. Construct with persistence='local' "
                "(or a directory), or call save(path=...).")
        return safe_save(self._spu, p)

    async def asave(self, path=None):
        """Async save() — see tessera.core.to_thread."""
        return await to_thread(self.save, path)

    @classmethod
    def load(cls, name, persistence="local", path=None):
        """Loads from `path` if given, else the default (name, persistence)
        location, and binds further saves to that same actual path.

        If the loaded state recorded its own logical name (every save()
        since this fix does), THAT name is used instead of the `name`
        argument — previously an explicit-path load with a mismatched
        `name` silently returned an empty state() (the data was filed
        under the original name's descriptor unit, not the caller's
        possibly-wrong label)."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.tessera.json")
        spu = safe_load(p)
        saved_name = spu.desc.get(_IDENTITY_KEY, {}).get("name", name)
        inst = cls(saved_name, persistence=persistence, _spu=spu)
        inst._path = p
        return inst

    @classmethod
    async def aload(cls, name, persistence="local", path=None):
        """Async load() — see tessera.core.to_thread."""
        return await to_thread(cls.load, name, persistence, path)

    @classmethod
    def open(cls, name, persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        p = save_path(name, persistence, "tessera.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(name, persistence=persistence)

    @classmethod
    async def aopen(cls, name, persistence=None):
        """Async open() — see tessera.core.to_thread."""
        return await to_thread(cls.open, name, persistence)

    @classmethod
    def create(cls, name, persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "tessera.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Field.create: a save already exists for {name!r} at {p} — "
                f"use Field.open() to resume it, or Field.load() if you expect it to exist."
            )
        return cls(name, persistence=persistence)

    @classmethod
    async def acreate(cls, name, persistence=None):
        """Async create() — see tessera.core.to_thread."""
        return await to_thread(cls.create, name, persistence)

    def history(self):
        """Every observe/run, in order — the replayable event log.
        Deep-copied on the way out — mutating a returned entry can no
        longer change stored history."""
        return copy.deepcopy(self._spu.cache.get(_EVENTS, []))

    def _log(self, kind, payload):
        """Deep-copies `payload` before storing it — a caller mutating the
        dict they passed to observe()/run() afterward can no longer change
        what was actually recorded."""
        self._spu.cache.setdefault(_EVENTS, []).append(
            {"t": self._spu._t, "kind": kind, "payload": copy.deepcopy(payload)})

    def __repr__(self):
        where = "memory" if self._path is None else str(self._path)
        return f"Field({self.name!r}, {where}, events={len(self.history())})"
