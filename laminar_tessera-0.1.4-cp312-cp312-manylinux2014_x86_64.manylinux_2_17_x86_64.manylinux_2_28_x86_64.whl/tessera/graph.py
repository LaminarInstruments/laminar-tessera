"""
tessera.graph — track connections.

How things relate: what depends on what, which pieces matter most, and how a
change ripples out.

    from tessera.graph import Graph

    g = Graph()
    g.connect("order", "payment").connect("payment", "ledger")
    g.degree("payment")        # 2
    g.path("order", "ledger")  # ['order', 'payment', 'ledger']
    g.rank()                   # nodes by importance (most-connected first)
    g.reach("order")           # how far each node is from 'order'

Backed by SPU121 graph opcodes: FORM_ACTIVITY, REMOVE_ACTIVITY,
COMPUTE_DEGREE, TRACE_ACTIVITY_PATH, COMPUTE_ACTIVITY_CENTRALITY,
RANK_ACTIVITY_IMPORTANCE, DETECT_ACTIVITY_CLUSTERS, PROPAGATE_ACTIVITY_EFFECT.
"""
from .core import SPU121, persist_dir, save_path, safe_save, safe_load

__all__ = ["Graph"]


class Graph:
    def __init__(self, persistence=None, name="graph", _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.graph.json") if self._dir else None

    def connect(self, a, b):
        """Create an undirected relationship between a and b.

        Raises ValueError on a self-loop (a == b), either side being None, or
        either side being unhashable (e.g. a list) — the engine's
        FORM_ACTIVITY silently no-ops on all three, which otherwise drops the
        edge with no signal at all.
        """
        if a is None or b is None:
            raise ValueError(f"Graph.connect: neither side may be None (got a={a!r}, b={b!r})")
        if a == b:
            raise ValueError(f"Graph.connect: self-loop rejected (a == b == {a!r})")
        for node in (a, b):
            try:
                hash(node)
            except TypeError:
                raise ValueError(f"Graph.connect: node must be hashable, got {type(node).__name__}: {node!r}") from None
        self._spu.execute("FORM_ACTIVITY", a=a, b=b)
        return self

    def disconnect(self, a, b):
        self._spu.execute("REMOVE_ACTIVITY", a=a, b=b)
        return self

    def neighbors(self, node):
        return sorted(self._spu.graph.get(node, set()), key=str)

    def degree(self, node):
        """How many things connect to this node."""
        return self._spu.execute("COMPUTE_DEGREE", node=node)

    def path(self, a, b):
        """Shortest chain of relationships from a to b (or None)."""
        return self._spu.execute("TRACE_ACTIVITY_PATH", a=a, b=b)

    def centrality(self):
        """node -> how central it is (0..1), by connection fraction."""
        return self._spu.execute("COMPUTE_ACTIVITY_CENTRALITY")

    def rank(self):
        """Nodes ordered by importance (most-connected first)."""
        return self._spu.execute("RANK_ACTIVITY_IMPORTANCE")

    def clusters(self):
        """Connected groups — islands of related nodes."""
        return self._spu.execute("DETECT_ACTIVITY_CLUSTERS")

    def reach(self, node):
        """node -> hops away from the given start (how a change ripples out)."""
        return self._spu.execute("PROPAGATE_ACTIVITY_EFFECT", node=node)

    def edges(self):
        return self._spu.edges

    def save(self, path=None):
        p = path or self._path
        if p is None:
            raise ValueError("In-memory Graph: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    @classmethod
    def load(cls, name="graph", persistence="local", path=None):
        d = persist_dir(persistence)
        p = path or (d / f"{name}.graph.json")
        return cls(persistence=persistence, name=name, _spu=safe_load(p))

    @classmethod
    def open(cls, name="graph", persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        p = save_path(name, persistence, "graph.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(persistence=persistence, name=name)

    @classmethod
    def create(cls, name="graph", persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "graph.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Graph.create: a save already exists for {name!r} at {p} — "
                f"use Graph.open() to resume it, or Graph.load() if you expect it to exist."
            )
        return cls(persistence=persistence, name=name)

    def __repr__(self):
        return f"Graph({self.name!r}, nodes={len(self._spu.graph)}, edges={self._spu.edges})"
