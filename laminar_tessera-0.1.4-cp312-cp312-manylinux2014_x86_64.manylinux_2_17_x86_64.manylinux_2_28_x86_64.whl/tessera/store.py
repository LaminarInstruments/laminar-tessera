"""
tessera.store — keep it safe.

Durable, embedded key/value state with all-or-nothing transactions and exact
rollback. No server.

    from tessera.store import Store

    s = Store.open(persistence="local", name="inventory")   # load-or-create
    s.put("widgets", 120)
    with s.transaction():          # all-or-nothing
        s.put("widgets", 80)
        raise RuntimeError("oops") # -> rolled back; widgets is still 120
    s.save()

Backed by SPU121 descriptors (the KV) and BEGIN/COMMIT/ROLLBACK_TRANSACTION
(the atomicity). save()/load() are the engine's atomic durable persistence.
"""
from .core import SPU121, persist_dir, save_path, safe_save, safe_load

__all__ = ["Store"]

_UNIT = "__store__"
_KEY_TYPES = "__store_key_types__"


class _Txn:
    """Context manager: commit on clean exit, roll back on any exception."""
    def __init__(self, spu):
        self._spu = spu

    def __enter__(self):
        self._spu.execute("BEGIN_TRANSACTION")
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type is None:
            self._spu.execute("COMMIT_TRANSACTION")
        else:
            self._spu.execute("ROLLBACK_TRANSACTION")
        return False   # never swallow the exception — rollback then re-raise


class Store:
    def __init__(self, persistence=None, name="store", _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.store.json") if self._dir else None

    def put(self, key, value):
        """Set key -> value.

        Raises ValueError if `key` stringifies to the same thing as a
        DIFFERENTLY-TYPED key already stored (e.g. put(1, ...) after
        put("1", ...)) — the engine's descriptor storage is string-keyed, so
        without this check the second put() silently overwrote the first
        with no error at all."""
        skey = str(key)
        this_repr = f"{type(key).__name__}:{key!r}"
        existing = self._spu.desc.get(_KEY_TYPES, {}).get(skey)
        if existing is not None and existing != this_repr:
            raise ValueError(
                f"Store.put: key {key!r} ({type(key).__name__}) collides with an "
                f"already-stored, differently-typed key that also stringifies to "
                f"{skey!r} ({existing}). Store keys are stringified internally — "
                f"use consistent key types, or call store.delete() first if you "
                f"intend to replace it."
            )
        self._spu.execute("ADD_DESCRIPTOR", unit=_KEY_TYPES, key=skey, value=this_repr)
        self._spu.execute("ADD_DESCRIPTOR", unit=_UNIT, key=skey, value=value)
        return self

    def get(self, key, default=None):
        return self._spu.desc.get(_UNIT, {}).get(str(key), default)

    def delete(self, key):
        skey = str(key)
        self._spu.execute("REMOVE_DESCRIPTOR", unit=_UNIT, key=skey)
        self._spu.execute("REMOVE_DESCRIPTOR", unit=_KEY_TYPES, key=skey)
        return self

    def keys(self):
        return list(self._spu.desc.get(_UNIT, {}).keys())

    def items(self):
        return dict(self._spu.desc.get(_UNIT, {}))

    def __contains__(self, key):
        return str(key) in self._spu.desc.get(_UNIT, {})

    def __len__(self):
        return len(self._spu.desc.get(_UNIT, {}))

    def transaction(self):
        """All-or-nothing block. On any exception, every write inside is undone."""
        return _Txn(self._spu)

    def save(self, path=None):
        p = path or self._path
        if p is None:
            raise ValueError("In-memory Store: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    @classmethod
    def load(cls, name="store", persistence="local", path=None):
        d = persist_dir(persistence)
        p = path or (d / f"{name}.store.json")
        return cls(persistence=persistence, name=name, _spu=safe_load(p))

    @classmethod
    def open(cls, name="store", persistence=None):
        """Load existing state if a save already exists for (name,
        persistence); otherwise create fresh. THE safe entry point for any
        restart path — see COOKBOOK.md Part 2.0. The plain constructor does
        NOT check for an existing save and will silently destroy it on the
        next save() if you construct fresh instead of loading."""
        p = save_path(name, persistence, "store.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(persistence=persistence, name=name)

    @classmethod
    def create(cls, name="store", persistence=None):
        """Create new state; raise FileExistsError if a save already exists
        for (name, persistence). Use this when resuming old state would
        itself be a bug — e.g. provisioning a brand-new entity that must not
        collide with a prior one of the same name."""
        p = save_path(name, persistence, "store.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Store.create: a save already exists for {name!r} at {p} — "
                f"use Store.open() to resume it, or Store.load() if you expect it to exist."
            )
        return cls(persistence=persistence, name=name)

    def __repr__(self):
        return f"Store({self.name!r}, keys={len(self)})"
