"""
tessera.workflow — finish the job.

Run a task that takes many steps. If it's interrupted, it resumes from exactly
the right spot — no repeating, no skipping. Each step's completion (and its
result) is persisted durably the moment it finishes.

    from tessera.workflow import Workflow

    def reserve(ctx): return {"held": ctx["qty"]}
    def charge(ctx):  return {"paid": True}
    def ship(ctx):    return {"tracking": "XZ-1"}

    wf = Workflow.open("checkout", persistence="local")
    wf.add("reserve", reserve); wf.add("charge", charge); wf.add("ship", ship)
    wf.run({"qty": 3})          # if this dies after charge(), re-running:

    resumed = Workflow.open("checkout", persistence="local")
    resumed.add("reserve", reserve); resumed.add("charge", charge); resumed.add("ship", ship)
    resumed.run({"qty": 3})     # resumes AT ship() — already-done steps are skipped, not re-run

IMPORTANT: .load()/.open() restore which steps already completed, but NOT the
Python step functions themselves (never serializable) — you must re-add every
step, by name, on every process that might resume a workflow, including ones
already done. If you don't, run() now raises MissingWorkflowStepsError rather
than silently skipping the unregistered work (see COOKBOOK.md Part "Gotcha 2").

Backed by SPU121: step completion/results live in descriptors, state is
checkpointed (CHECKPOINT_STATE) and saved atomically after every step.
"""
from .core import SPU121, persist_dir, save_path, safe_save, safe_load

__all__ = ["Workflow", "MissingWorkflowStepsError"]

_DONE = "__wf_done__"
_RESULT = "__wf_result__"
_EXPECTED = "__wf_expected__"


class MissingWorkflowStepsError(ValueError):
    """Raised by run() when a step that's part of this workflow (registered
    on some earlier run) has neither completed yet NOR been re-registered on
    this object. Without this check, run() would silently skip it and return
    a normal-looking result — indistinguishable from success."""
    pass


class Workflow:
    def __init__(self, name, persistence=None, _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.workflow.json") if self._dir else None
        self._steps = []   # [(step_name, fn)]

    def step(self, fn):
        """Decorator: register a step, run in registration order."""
        self.add(fn.__name__, fn)
        return fn

    def add(self, name, fn):
        """Register a step function under `name`.

        Raises ValueError if `name` is already registered on THIS object.
        Without this check, two steps sharing a name both ran their side
        effects on run() (only the last one's result was ever visible) — a
        silent double-execution, dangerous for any step with an external
        effect. This does not affect the normal resume pattern: a reloaded
        Workflow's `_steps` list starts empty, so re-adding each step once
        per process is still exactly one registration, not a duplicate.
        """
        if any(existing_name == name for existing_name, _ in self._steps):
            raise ValueError(f"Workflow.add: step {name!r} is already registered on this object")
        self._steps.append((name, fn))
        return self

    def completed(self):
        """Names of steps already done (persisted)."""
        return list(self._spu.desc.get(_DONE, {}).keys())

    def run(self, ctx=None):
        """Run every not-yet-completed step in order. Returns the context dict,
        pre-seeded with results from any steps completed in a previous run.

        Raises MissingWorkflowStepsError if a step this workflow is known to
        need (registered on some earlier run()) is neither re-registered on
        this object nor already completed — instead of silently returning
        having skipped it."""
        ctx = {} if ctx is None else dict(ctx)
        current_names = [name for name, _ in self._steps]
        done = set(self.completed())

        expected = self._spu.desc.get(_EXPECTED, {}).get("names")
        if expected is not None:
            missing = [n for n in expected if n not in current_names and n not in done]
            if missing:
                raise MissingWorkflowStepsError(
                    f"Workflow.run: step(s) {missing!r} are part of this workflow "
                    f"(from an earlier run) and are not yet completed, but were not "
                    f"re-registered via add()/@step before calling run(). Re-add "
                    f"every step, by name, on every process that might resume this "
                    f"workflow — including ones you believe already completed "
                    f"(they're safely skipped, not re-run). Refusing to silently "
                    f"skip {missing!r}."
                )

        # Record the full set of steps THIS run() call knows about, durably,
        # BEFORE running anything — not after the loop finishes. A crash can
        # happen mid-step (that's the whole scenario this check exists for),
        # so if this were recorded only at the end, a crash during the very
        # step this check is meant to catch would mean it never got saved at
        # all, silently defeating the check on the next resume.
        merged_expected = sorted(set(expected or []) | set(current_names))
        if merged_expected != sorted(expected or []):
            self._spu.execute("ADD_DESCRIPTOR", unit=_EXPECTED, key="names", value=merged_expected)
            if self._path:
                safe_save(self._spu, self._path)

        # restore results from steps that completed before an interruption
        for k, v in self._spu.desc.get(_RESULT, {}).items():
            ctx.setdefault(k, v)

        for name, fn in self._steps:
            if name in done:
                continue
            result = fn(ctx)
            ctx[name] = result   # always stored, even None — "did it run" and
                                  # "is its result present" now mean the same thing
            self._spu.execute("ADD_DESCRIPTOR", unit=_RESULT, key=name, value=result)
            self._spu.execute("ADD_DESCRIPTOR", unit=_DONE, key=name, value=True)
            self._spu.execute("CHECKPOINT_STATE", name=name)
            if self._path:          # durable the instant the step is done
                safe_save(self._spu, self._path)

        return ctx

    def reset(self):
        """Clear all progress (start the job over)."""
        self._spu.desc.pop(_DONE, None)
        self._spu.desc.pop(_RESULT, None)
        self._spu.desc.pop(_EXPECTED, None)
        if self._path:
            safe_save(self._spu, self._path)
        return self

    @classmethod
    def load(cls, name, persistence="local", path=None):
        d = persist_dir(persistence)
        p = path or (d / f"{name}.workflow.json")
        return cls(name, persistence=persistence, _spu=safe_load(p))

    @classmethod
    def open(cls, name, persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0. You must still re-add every step after this
        call; open() alone does not restore the step functions."""
        p = save_path(name, persistence, "workflow.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(name, persistence=persistence)

    @classmethod
    def create(cls, name, persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "workflow.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Workflow.create: a save already exists for {name!r} at {p} — "
                f"use Workflow.open() to resume it, or Workflow.load() if you expect it to exist."
            )
        return cls(name, persistence=persistence)

    def __repr__(self):
        return f"Workflow({self.name!r}, done={self.completed()})"
