"""
tessera.agents — remember & decide.

Watch what's happening, try a choice safely on a branch without touching live
state, keep the one you want, survive a crash, and replay the history.

    from tessera.agents import Field, Program

    agent = Field("warehouse", persistence="local")
    agent.observe({"stock": 120, "demand": 145})

    branch = agent.fork()                       # explore a future in isolation
    branch.run(Program("restock"), quantity=100)
    agent.commit(branch)                         # keep that choice
    agent.save()                                 # survives a crash, replays exactly

Backed by SPU121: observations are descriptors + measurements, fork is an
isolated engine copy, save/load are the engine's atomic durable persistence,
and the event log rides in the engine's own persisted state.
"""
import copy
import warnings

from .core import SPU121, persist_dir, save_path, safe_save, safe_load

__all__ = ["Field", "Program", "program"]

_EVENTS = "__events__"       # event log, kept in the engine's persisted cache
_WF_DONE = "__wf_done__"


class Program:
    """A named thing an agent can run.

    Three honest forms, in order of power:
      Program("restock")                         -> records the intent + applies
                                                    any kwargs as state (replayable)
      Program("restock", fn=lambda f, **kw: ...) -> a Python function over the field
      Program("restock", steps=[("ADD_MEASUREMENT", {"series": "x"}), ...])
                                                 -> an explicit opcode sequence
    """
    def __init__(self, name, fn=None, steps=None):
        self.name = name
        self.fn = fn
        self.steps = list(steps or [])

    def __repr__(self):
        return f"Program({self.name!r})"


def program(fn):
    """Decorator: turn a function into a Program named after it."""
    return Program(fn.__name__, fn=fn)


class Field:
    """An agent's unified state — memory, relationships, and decisions in one."""

    def __init__(self, name, persistence=None, _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.tessera.json") if self._dir else None

    # -- observe --------------------------------------------------------------
    def observe(self, observations):
        """Record what the agent sees. Scalars become both a descriptor (the
        current value) and a measurement (the running series, for stats)."""
        for key, value in dict(observations).items():
            self._spu.execute("ADD_DESCRIPTOR", unit=self.name, key=str(key), value=value)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                self._spu.execute("ADD_MEASUREMENT", series=str(key), value=float(value))
        self._log("observe", dict(observations))
        return self

    def state(self):
        """The agent's current view: key -> latest value."""
        return dict(self._spu.desc.get(self.name, {}))

    # -- branch / decide ------------------------------------------------------
    def fork(self):
        """An isolated copy to explore a future on. Changes here do NOT touch
        this field until you commit() them back.

        A true deep copy — not to_dict()/from_dict(), which shares the engine's
        live dicts (that round-trip is only independent once it goes through
        JSON on disk)."""
        twin = copy.deepcopy(self._spu)
        f = Field(self.name, persistence=None, _spu=twin)
        return f

    def run(self, program, **kwargs):
        """Run a Program against this field, mutating its state."""
        if program.fn is not None:
            result = program.fn(self, **kwargs)
            if result is not None:
                warnings.warn(
                    f"Program {program.name!r}: fn returned {result!r}, but an "
                    f"fn-form Program's return value is discarded, not applied to "
                    f"the field — call field.observe(...) inside fn if you want "
                    f"it recorded.",
                    stacklevel=2,
                )
        elif program.steps:
            for op, kw in program.steps:
                self._spu.execute(op, **{**kw, **kwargs})
        else:
            # no body: record the intent and fold kwargs into state — still a
            # real, replayable state change, not a no-op.
            for key, value in kwargs.items():
                self._spu.execute("ADD_DESCRIPTOR", unit=self.name, key=str(key), value=value)
        self._log("run", {"program": program.name, **kwargs})
        return self

    def commit(self, branch=None):
        """Keep a decision. With a branch, adopt the future you explored on it."""
        if branch is not None:
            self._spu = copy.deepcopy(branch._spu)
        return self

    # -- durability & replay --------------------------------------------------
    def save(self, path=None):
        """Persist durably (atomic write + fsync). Survives a crash."""
        p = path or self._path
        if p is None:
            raise ValueError(
                "This Field is in-memory. Construct with persistence='local' "
                "(or a directory), or call save(path=...).")
        return safe_save(self._spu, p)

    @classmethod
    def load(cls, name, persistence="local", path=None):
        d = persist_dir(persistence)
        p = path or (d / f"{name}.tessera.json")
        return cls(name, persistence=persistence, _spu=safe_load(p))

    @classmethod
    def open(cls, name, persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        p = save_path(name, persistence, "tessera.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(name, persistence=persistence)

    @classmethod
    def create(cls, name, persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "tessera.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Field.create: a save already exists for {name!r} at {p} — "
                f"use Field.open() to resume it, or Field.load() if you expect it to exist."
            )
        return cls(name, persistence=persistence)

    def history(self):
        """Every observe/run, in order — the replayable event log."""
        return list(self._spu.cache.get(_EVENTS, []))

    def _log(self, kind, payload):
        self._spu.cache.setdefault(_EVENTS, []).append(
            {"t": self._spu._t, "kind": kind, "payload": payload})

    def __repr__(self):
        where = "memory" if self._path is None else str(self._path)
        return f"Field({self.name!r}, {where}, events={len(self.history())})"
