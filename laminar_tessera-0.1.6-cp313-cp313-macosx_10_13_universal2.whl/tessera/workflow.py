"""
tessera.workflow — finish the job.

Run a task that takes many steps. If it's interrupted, it resumes from exactly
the right spot — no repeating, no skipping. Each step's completion (and its
result) is persisted durably the moment it finishes.

    from tessera.workflow import Workflow

    def reserve(ctx): return {"held": ctx["qty"]}
    def charge(ctx):  return {"paid": True}
    def ship(ctx):    return {"tracking": "XZ-1"}

    wf = Workflow.open("checkout", persistence="local")
    wf.add("reserve", reserve); wf.add("charge", charge); wf.add("ship", ship)
    wf.run({"qty": 3})          # if this dies after charge(), re-running:

    resumed = Workflow.open("checkout", persistence="local")
    resumed.add("reserve", reserve); resumed.add("charge", charge); resumed.add("ship", ship)
    resumed.run({"qty": 3})     # resumes AT ship() — already-done steps are skipped, not re-run

IMPORTANT: .load()/.open() restore which steps already completed, but NOT the
Python step functions themselves (never serializable) — you must re-add every
step, by name, on every process that might resume a workflow, including ones
already done. If you don't, run() now raises MissingWorkflowStepsError rather
than silently skipping the unregistered work (see COOKBOOK.md Part "Gotcha 2").

Backed by SPU121: step completion/results live in descriptors, state is
checkpointed (CHECKPOINT_STATE) and saved atomically after every step.
"""
import copy
import inspect

from .core import (SPU121, persist_dir, save_path, safe_save, safe_load,
                    prepare_for_persistence)

__all__ = ["Workflow", "MissingWorkflowStepsError"]

_DONE = "__wf_done__"
_RESULT = "__wf_result__"
_EXPECTED = "__wf_expected__"
_ORDER = "__wf_order__"
_CP_PREFIX = "__workflow_step__:"   # namespaces step checkpoints away from any
                                    # application-level CHECKPOINT_STATE name


class MissingWorkflowStepsError(ValueError):
    """Raised by run() when a step that's part of this workflow (registered
    on some earlier run) has neither completed yet NOR been re-registered on
    this object. Without this check, run() would silently skip it and return
    a normal-looking result — indistinguishable from success."""
    pass


class Workflow:
    def __init__(self, name, persistence=None, _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.workflow.json") if self._dir else None
        self._steps = []   # [(step_name, fn)]
        self._running = False

    def step(self, fn):
        """Decorator: register a step, run in registration order."""
        self.add(fn.__name__, fn)
        return fn

    def add(self, name, fn):
        """Register a step function under `name`.

        Raises ValueError if `name` is already registered on THIS object, if
        `name` is not a str (an int/other step name round-trips through the
        persisted completion dict as a STRING via JSON, so completed()
        lookups by the original type silently miss and the step re-runs),
        or if called while run() is already executing on this object (a
        step's own callback calling add() used to let a dynamically-added
        step escape the persisted manifest entirely). Raises TypeError if
        `fn` isn't callable, or is an async function (its body would never
        actually be awaited/run — see run()'s matching check for a callable
        that only returns an awaitable)."""
        if self._running:
            raise ValueError(
                "Workflow.add: cannot register a new step while run() is executing "
                "on this object — registration is frozen during a run so a step's "
                "own callback can't silently add work outside the persisted manifest."
            )
        if not isinstance(name, str):
            raise TypeError(
                f"Workflow.add: step name must be a str, got {type(name).__name__}: {name!r} "
                f"— persisted completion is JSON-keyed (always strings on reload), so a "
                f"non-str name looks completed in memory but not after a restart."
            )
        if not callable(fn):
            raise TypeError(f"Workflow.add: step {name!r}'s fn must be callable, got {type(fn).__name__}")
        if inspect.iscoroutinefunction(fn):
            raise TypeError(
                f"Workflow.add: step {name!r} is an async function — its body would "
                f"never actually run (nothing awaits it). Workflow's step interface is "
                f"synchronous; run the coroutine to completion yourself inside a plain "
                f"function if you need to call async code from a step."
            )
        if any(existing_name == name for existing_name, _ in self._steps):
            raise ValueError(f"Workflow.add: step {name!r} is already registered on this object")
        self._steps.append((name, fn))
        return self

    def completed(self):
        """Names of steps already done (persisted)."""
        return list(self._spu.desc.get(_DONE, {}).keys())

    def run(self, ctx=None):
        """Run every not-yet-completed step in order. Returns the context dict.

        Completed steps' persisted results are restored into ctx
        AUTHORITATIVELY (they win over any conflicting field the caller
        passed in) — a resume reflects what actually happened, not whatever
        the caller's ctx claims this time.

        Raises MissingWorkflowStepsError if a step this workflow is known to
        need (registered on some earlier run()) is neither re-registered on
        this object nor already completed — instead of silently returning
        having skipped it.

        Raises ValueError if this object's current, not-yet-completed step
        order doesn't match the order those same steps were originally
        registered in (across a resume, re-adding steps in a different
        relative order used to silently execute them out of the originally
        defined sequence).

        Raises RuntimeError if called reentrantly (e.g. a step's own
        callback calling run() again on this same object) — this used to
        let a still-in-flight step's effects run twice."""
        if self._running:
            raise RuntimeError(
                "Workflow.run: reentrant call on the same Workflow object — a step's "
                "callback (or something it called) invoked run() again while the "
                "outer run() is still executing. This used to let the in-flight "
                "step's effects run twice."
            )
        self._running = True
        try:
            return self._run(ctx)
        finally:
            self._running = False

    def _run(self, ctx):
        ctx = {} if ctx is None else dict(ctx)
        current_names = [name for name, _ in self._steps]
        done = set(self.completed())

        expected = self._spu.desc.get(_EXPECTED, {}).get("names")
        if expected is not None:
            missing = [n for n in expected if n not in current_names and n not in done]
            if missing:
                raise MissingWorkflowStepsError(
                    f"Workflow.run: step(s) {missing!r} are part of this workflow "
                    f"(from an earlier run) and are not yet completed, but were not "
                    f"re-registered via add()/@step before calling run(). Re-add "
                    f"every step, by name, on every process that might resume this "
                    f"workflow — including ones you believe already completed "
                    f"(they're safely skipped, not re-run). Refusing to silently "
                    f"skip {missing!r}."
                )

        # Persisted step ORDER (not just the set of names) — the sequence
        # steps were first ever registered in, append-only for genuinely new
        # names. A later resume's pending (not-done) steps must appear on
        # THIS object in that same relative order.
        persisted_order = list(self._spu.desc.get(_ORDER, {}).get("names") or [])
        merged_order = persisted_order + [n for n in current_names if n not in persisted_order]
        pending_persisted = [n for n in merged_order if n not in done]
        pending_current = [n for n in current_names if n not in done]
        if pending_persisted != pending_current:
            raise ValueError(
                f"Workflow.run: this object's pending step order {pending_current!r} "
                f"does not match the originally registered order {pending_persisted!r} "
                f"for the steps not yet completed. Re-add steps in the same relative "
                f"order they were first registered in."
            )

        # Record the full set/order of steps THIS run() call knows about,
        # durably, BEFORE running anything — not after the loop finishes. A
        # crash can happen mid-step (that's the whole scenario this check
        # exists for), so if this were recorded only at the end, a crash
        # during the very step this check is meant to catch would mean it
        # never got saved at all, silently defeating the check on resume.
        merged_expected = sorted(set(expected or []) | set(current_names))
        if merged_expected != sorted(expected or []) or merged_order != persisted_order:
            self._spu.execute("ADD_DESCRIPTOR", unit=_EXPECTED, key="names", value=merged_expected)
            self._spu.execute("ADD_DESCRIPTOR", unit=_ORDER, key="names", value=merged_order)
            if self._path:
                safe_save(self._spu, self._path)

        # restore results from steps that completed before an interruption —
        # authoritative: a completed result overrides any caller-supplied ctx
        # field of the same name (ctx is only the seed for steps not yet run).
        for k, v in self._spu.desc.get(_RESULT, {}).items():
            ctx[k] = copy.deepcopy(v)

        for name, fn in self._steps:
            if name in done:
                continue
            result = fn(ctx)
            if inspect.isawaitable(result):
                raise TypeError(
                    f"Workflow step {name!r} returned an awaitable (its body may never "
                    f"have actually run — nothing awaited it). Workflow's step interface "
                    f"is synchronous; run the coroutine to completion yourself inside the "
                    f"step function and return its real result."
                )
            try:
                result = prepare_for_persistence(result, path=f"Workflow step {name!r}'s result")
            except (TypeError, ValueError) as e:
                raise TypeError(
                    f"{e} Rejected before marking the step complete, so in-memory and "
                    f"durable completion stay consistent — a save failure no longer "
                    f"leaves this step looking done in memory while never being "
                    f"recorded on disk. (This also catches a tuple silently becoming a "
                    f"list, or two dict keys colliding once stringified, only after a "
                    f"resume — both are normalized/validated immediately now.)"
                ) from None
            result = copy.deepcopy(result)
            ctx[name] = result   # always stored, even None — "did it run" and
                                  # "is its result present" now mean the same thing
            self._spu.execute("ADD_DESCRIPTOR", unit=_RESULT, key=name, value=copy.deepcopy(result))
            self._spu.execute("ADD_DESCRIPTOR", unit=_DONE, key=name, value=True)
            self._spu.execute("CHECKPOINT_STATE", name=f"{_CP_PREFIX}{self.name}:{name}")
            if self._path:          # durable the instant the step is done
                safe_save(self._spu, self._path)

        return ctx

    def reset(self):
        """Clear all progress (start the job over)."""
        self._spu.desc.pop(_DONE, None)
        self._spu.desc.pop(_RESULT, None)
        self._spu.desc.pop(_EXPECTED, None)
        self._spu.desc.pop(_ORDER, None)
        if self._path:
            safe_save(self._spu, self._path)
        return self

    @classmethod
    def load(cls, name, persistence="local", path=None):
        """Loads from `path` if given, else the default (name, persistence)
        location, and binds further saves to that actual path — previously
        an explicit `path` was used only to read, then silently dropped, so
        a subsequent save() went to the default filename instead."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.workflow.json")
        inst = cls(name, persistence=persistence, _spu=safe_load(p))
        inst._path = p
        return inst

    @classmethod
    def open(cls, name, persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0. You must still re-add every step after this
        call; open() alone does not restore the step functions."""
        p = save_path(name, persistence, "workflow.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(name, persistence=persistence)

    @classmethod
    def create(cls, name, persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "workflow.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Workflow.create: a save already exists for {name!r} at {p} — "
                f"use Workflow.open() to resume it, or Workflow.load() if you expect it to exist."
            )
        return cls(name, persistence=persistence)

    def __repr__(self):
        return f"Workflow({self.name!r}, done={self.completed()})"
