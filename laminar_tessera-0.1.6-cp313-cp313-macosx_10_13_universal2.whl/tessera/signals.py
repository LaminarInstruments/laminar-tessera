"""
tessera.signals — watch the numbers.

Follow a live stream of readings, learn what "normal" looks like, and flag the
moment something's off.

    from tessera.signals import Signals

    sig = Signals()
    sig.measure("hr", [72, 75, 71, 80, 69, 77])
    sig.stats("hr")                 # {'n':..,'mean':..,'std':..}
    sig.entropy([72, 75, 71, 80])   # disorder in bits (0 = flat, higher = chaotic)
    sig.anomalies("hr", threshold=3)# indices that sit >3 std from the mean
    escalate, e = sig.gate([72, 250, 71, 69], threshold=1.5)

Backed by SPU121: ADD_MEASUREMENT, EXTRACT_SUMMARY_STATISTICS,
COMPUTE_METRIC_CORRELATION, DETECT_ANOMALIES, COMPUTE_ENTROPY (over an 8-bin
histogram, so a flat series reads low and a spread-out one reads high).
"""
import math

from .core import SPU121, persist_dir, histogram8, save_path, safe_save, safe_load

__all__ = ["Signals"]

_MAX_ABS_MEASUREMENT = 1e15


class Signals:
    def __init__(self, persistence=None, name="signals", _spu=None):
        self.name = name
        self.persistence = persistence
        self._spu = _spu if _spu is not None else SPU121()
        self._dir = persist_dir(persistence)
        self._path = (self._dir / f"{name}.signals.json") if self._dir else None

    def measure(self, series, values):
        """Add one or more readings to a named stream.

        Raises TypeError if `series` isn't a str — the engine's measurement
        store is keyed by whatever object `series` is, and distinct int/str
        series that stringify the same way (e.g. 7 and "7") silently
        collapsed into one series the moment the Space was persisted (JSON
        object keys are always strings).

        Raises ValueError for any reading with abs(value) > 1e15. This used
        to be silently sanitized to 0.0 by the shared dispatch sanitizer —
        a real, accepted finite number quietly becoming zero with no error
        at all. That sanitizer now only catches NaN/Inf (which stay 0.0,
        unchanged); the magnitude cap lives here instead, scoped to
        Signals specifically, because it exists for THIS door's
        mean/std/anomaly math (see stats()/anomalies()), not as a
        general-purpose limit on every door's numbers (Store, for
        instance, now preserves any finite float exactly)."""
        if not isinstance(series, str):
            raise TypeError(
                f"Signals.measure: series must be a str, got {type(series).__name__}: "
                f"{series!r} — persistence (JSON) can only key a series by string, so a "
                f"non-str series name that happens to stringify the same as another "
                f"series silently merges with it on the next save/reload."
            )
        vals = values if isinstance(values, (list, tuple)) else [values]
        fvals = [float(v) for v in vals]
        for v in fvals:
            if math.isfinite(v) and abs(v) > _MAX_ABS_MEASUREMENT:
                raise ValueError(
                    f"Signals.measure: reading {v!r} exceeds the supported magnitude "
                    f"(abs(value) <= {_MAX_ABS_MEASUREMENT:g}) for series {series!r}. "
                    f"Scale the value down, or use tessera.store for a general-purpose "
                    f"number that doesn't need this door's statistics."
                )
        self._spu.execute("ADD_MEASUREMENT", series=series, data=fvals)
        return self

    def _require_measured(self, series, method):
        """Raise instead of letting the engine fabricate a phantom
        {'n': 1, 'mean': 0.0, 'std': 0.0}-shaped reading for a series that
        was never measured (or only ever measured with an empty list) — a
        typo'd series name used to look indistinguishable from "one real
        zero reading."""
        if series not in self._spu.meas or len(self._spu.meas[series]) == 0:
            raise ValueError(
                f"Signals.{method}: no measurements recorded for series {series!r} "
                f"— call measure({series!r}, ...) first. (Previously this silently "
                f"returned a fabricated zero-reading instead of raising.)"
            )

    def stats(self, series):
        """Running count / mean / std for a stream."""
        self._require_measured(series, "stats")
        result = self._spu.execute("EXTRACT_SUMMARY_STATISTICS", series=series)
        if result is None:
            # Defensive fallback only — not reachable via any known input.
            # An earlier version of this comment claimed an extreme-magnitude
            # value (~1e308) would overflow here; adversarial testing proved
            # that false (Python's statistics.fmean/pstdev stayed numerically
            # stable all the way to float64's actual max). The real fix for
            # that failure mode is upstream: measure() now sanitizes any
            # |value| > 1e15 to 0.0, the same bucket as NaN/inf, before it can
            # ever poison a series. This branch stays as a defensive fallback
            # in case a future engine change ever does return None.
            raise ArithmeticError(
                f"Signals.stats: internal computation returned no result for series "
                f"{series!r} instead of the documented dict."
            )
        return result

    def correlate(self, series_a, series_b):
        """How tightly two streams move together (-1..1), or None if either
        series has zero variance (a constant series) — the Pearson
        coefficient is mathematically undefined there, and silently
        returning 0.0 was indistinguishable from "measured, no linear
        relationship." Clamped to exactly [-1.0, 1.0] when defined (a
        floating-point computation can round a step past 1.0 or -1.0 by
        one bit for a mathematically perfect correlation)."""
        self._require_measured(series_a, "correlate")
        self._require_measured(series_b, "correlate")
        len_a, len_b = len(self._spu.meas[series_a]), len(self._spu.meas[series_b])
        if len_a != len_b:
            raise ValueError(
                f"Signals.correlate: series {series_a!r} has {len_a} readings but "
                f"{series_b!r} has {len_b} — correlate() requires equal-length series "
                f"(previously this silently computed from the overlapping prefix)."
            )
        return self._spu.execute("COMPUTE_METRIC_CORRELATION", a=series_a, b=series_b)

    def anomalies(self, series, threshold=3):
        """Indices in the stream that sit more than `threshold` std from the mean.

        Raises ValueError if `threshold` isn't finite and nonnegative — a
        NaN threshold used to be silently sanitized to 0.0 by the shared
        dispatch sanitizer, which flagged nearly every nonzero deviation as
        an "anomaly" with no error or warning at all."""
        if not (isinstance(threshold, (int, float)) and not isinstance(threshold, bool)
                and math.isfinite(threshold) and threshold >= 0):
            raise ValueError(
                f"Signals.anomalies: threshold must be a finite, nonnegative number, "
                f"got {threshold!r}."
            )
        self._require_measured(series, "anomalies")
        result = self._spu.execute("DETECT_ANOMALIES", series=series, thr=threshold)
        if result is None:
            # Defensive fallback only — see the matching note in stats().
            raise ArithmeticError(
                f"Signals.anomalies: internal computation returned no result for "
                f"series {series!r} instead of the documented list."
            )
        return result

    def entropy(self, values):
        """Disorder in bits: a flat/steady series is low, a wild one is high."""
        return self._spu.execute("COMPUTE_ENTROPY", data=histogram8(values))

    def gate(self, values, threshold):
        """Cheap triage: (escalate?, entropy). Only escalate when disorder
        crosses the threshold — the rest of the pipeline stays asleep.

        Raises ValueError if `threshold` isn't finite — a NaN threshold
        used to be silently sanitized to 0.0, which always escalated
        (any positive entropy compares greater than a NaN-turned-zero)
        with no indication the configured threshold was invalid."""
        if not (isinstance(threshold, (int, float)) and not isinstance(threshold, bool)
                and math.isfinite(threshold)):
            raise ValueError(f"Signals.gate: threshold must be a finite number, got {threshold!r}.")
        e = self.entropy(values)
        return (e is not None and e > threshold), e

    def save(self, path=None):
        p = path or self._path
        if p is None:
            raise ValueError("In-memory Signals: construct with persistence='local' or save(path=...).")
        return safe_save(self._spu, p)

    @classmethod
    def load(cls, name="signals", persistence="local", path=None):
        """Loads from `path` if given, else the default (name, persistence)
        location, and binds further saves to that actual path — previously
        an explicit `path` was used only to read, then silently dropped, so
        a subsequent save() went to the default filename instead."""
        d = persist_dir(persistence)
        p = path or (d / f"{name}.signals.json")
        inst = cls(persistence=persistence, name=name, _spu=safe_load(p))
        inst._path = p
        return inst

    @classmethod
    def open(cls, name="signals", persistence=None):
        """Load existing state if a save already exists; otherwise create
        fresh. THE safe entry point for any restart path — see
        COOKBOOK.md Part 2.0."""
        p = save_path(name, persistence, "signals.json")
        if p is not None and p.exists():
            return cls.load(name, persistence=persistence)
        return cls(persistence=persistence, name=name)

    @classmethod
    def create(cls, name="signals", persistence=None):
        """Create new state; raise FileExistsError if a save already exists."""
        p = save_path(name, persistence, "signals.json")
        if p is not None and p.exists():
            raise FileExistsError(
                f"Signals.create: a save already exists for {name!r} at {p} — "
                f"use Signals.open() to resume it, or Signals.load() if you expect it to exist."
            )
        return cls(persistence=persistence, name=name)

    def __repr__(self):
        return f"Signals({self.name!r}, streams={len(self._spu.meas)})"
