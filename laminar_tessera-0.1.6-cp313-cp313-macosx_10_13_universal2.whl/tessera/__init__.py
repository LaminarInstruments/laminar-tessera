"""
Tessera — one engine, many doors.

The clean front door over the engine (tessera._engine.spu121.SPU121, the full
121-opcode software SPU). Everything your software needs to remember — memory,
relationships, measurement, decisions, durable workflow, replay, and adaptive
baselines — in one offline, deterministic, zero-dependency package. Enter
through whichever door fits the job; it's the same engine underneath, so they
compose.

    from tessera.agents   import Field, Program    # remember & decide
    from tessera.store    import Store             # keep it safe
    from tessera.graph    import Graph             # track connections
    from tessera.signals  import Signals           # watch the numbers
    from tessera.workflow import Workflow          # finish the job
    from tessera.replay   import EventLog          # prove what happened
    from tessera.baseline import AdaptiveBaseline  # learn what normal looks like

Nothing here reimplements the engine. Each door dispatches to real SPU opcodes.

    import tessera; tessera.engine_info()
    # {'engine': 'tessera._engine.spu121.SPU121 (compiled)', 'opcodes': 121, ...}

Created by Darreck L. Bender II, Founder, Laminar Instruments.
darreck@laminarinstruments.com · laminarinstruments.com · patent(s) pending.

Free to use, including commercially, while you're building — a commercial
license only kicks in once a product built on this SDK is doing real
revenue. See LICENSE.txt.
"""
from . import agents, store, graph, signals, workflow, replay, baseline
from .agents import Field, Program, program
from .store import Store
from .graph import Graph
from .signals import Signals
from .workflow import Workflow, MissingWorkflowStepsError
from .replay import EventLog
from .baseline import AdaptiveBaseline
from .space import Space
from .core import engine_info, ConcurrentWriteError, InvalidSaveFileError

__version__ = "0.1.6"
__author__ = "Darreck L. Bender II"
__email__ = "darreck@laminarinstruments.com"
__url__ = "https://laminarinstruments.com"
__all__ = [
    "agents", "store", "graph", "signals", "workflow", "replay", "baseline",
    "Field", "Program", "program", "Store", "Graph", "Signals",
    "Workflow", "EventLog", "AdaptiveBaseline", "Space", "engine_info", "__version__",
    "MissingWorkflowStepsError", "ConcurrentWriteError", "InvalidSaveFileError",
]
